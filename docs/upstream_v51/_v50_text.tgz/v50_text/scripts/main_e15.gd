extends Node2D







const MD = preload("res://scripts/moves_data.gd")
const TD = preload("res://scripts/types_data.gd")
const SV = preload("res://scripts/save_data.gd")
const Aud = preload("res://scripts/audio.gd")
const L = preload("res://scripts/lang.gd")
const IC = preload("res://scripts/icons.gd")
const PXF = preload("res://scripts/pxfont.gd")


const ENEMY_CAP: = 64
const AIM_REACH: = 520.0
const MAX_MOVES: = 4
const ORB_CAP: = 420
const BASE_MAGNET: = 78.0
const XP_ENEMY: = 20.0
const CHUNK: = 640.0
const SAFE_R: = 260.0
const POWERS: = [
	{"id": "fury", "name": "Furia", "desc": "+50% de daño", "color": "#ff6b4a"}, 
	{"id": "haste", "name": "Impulso", "desc": "+40% de velocidad", "color": "#ffd33d"}, 
	{"id": "aegis", "name": "Égida", "desc": "-40% de daño recibido", "color": "#7fc8ff"}, 
	{"id": "frenzy", "name": "Frenesí", "desc": "-35% de recarga", "color": "#c47bff"}, 
]
const LIFT: = 18.0

const MULT_KEYS: = ["dmg", "cd", "speed", "radius", "dur", "amount", "arc", "width", "spread", "life", "size", "rate"]
const ADD_KEYS: = ["count", "pierce", "stacks"]
const TARGETED: = ["melee", "beam", "projectile", "boomerang", "chain", "meteor", "dash", "cone"]

const FLASH_SHADER: = "shader_type canvas_item;\nuniform float flash : hint_range(0.0, 1.0) = 0.0;\nvoid fragment() {\n\tvec4 m = COLOR;\n\tvec4 c = texture(TEXTURE, UV);\n\tCOLOR = vec4(mix(c.rgb, vec3(1.0), flash), c.a) * m;\n}\n"


const ANIMS: = ["Idle", "Walk", "Attack", "Shoot", "Charge", "Hurt", "Faint"]
const ANIM_FOR: = {
	"melee": "Attack", "beam": "Shoot", "projectile": "Shoot", "nova": "Attack", "aura": "Charge", 
	"buff": "Charge", "orbit": "Charge", "boomerang": "Shoot", "chain": "Shoot", "mine": "Charge", 
	"meteor": "Charge", "turret": "Charge", "dash": "Attack", "trail": "Walk", "cone": "Shoot", 
}


const TIERS: = [
	{"from": 0, "bst": [180, 330], "hp": 17, "spd": 56, "dmg": 6.0, "xp": 3.5, "cast": 7}, 
	{"from": 70, "bst": [300, 405], "hp": 32, "spd": 62, "dmg": 8.5, "xp": 5.0, "cast": 7}, 
	{"from": 160, "bst": [385, 465], "hp": 52, "spd": 60, "dmg": 11.0, "xp": 8.0, "cast": 7}, 
	{"from": 260, "bst": [445, 515], "hp": 88, "spd": 70, "dmg": 14.0, "xp": 13.0, "cast": 7}, 
	{"from": 380, "bst": [495, 560], "hp": 150, "spd": 66, "dmg": 22.0, "xp": 24.0, "cast": 7}, 
	{"from": 500, "bst": [530, 620], "hp": 250, "spd": 72, "dmg": 28.0, "xp": 38.0, "cast": 7}, 
]

const BOSS_SLOTS: = [
	{"at": 180, "hp": 1400, "dmg": 34, "xp": 220, "bst": [490, 545]}, 
	{"at": 360, "hp": 3200, "dmg": 42, "xp": 420, "bst": [520, 580]}, 
	{"at": 540, "hp": 5600, "dmg": 48, "xp": 680, "bst": [540, 600]}, 
	{"at": 720, "hp": 9000, "dmg": 56, "xp": 1000, "bst": [580, 700]}, 
	{"at": 900, "hp": 16000, "dmg": 68, "xp": 1800, "bst": [600, 700]}, 
]
const HEAL_SET: = [35, 36, 113, 173, 183, 184, 242, 301, 440, 531, 594, 700, 764, 858]
const SHIELD_SET: = [95, 122, 208, 213, 227, 306, 375, 410, 411, 436, 437, 439, 476, 703]
const BOMB_SET: = [74, 75, 76, 100, 101, 102, 109, 110, 337, 338, 343, 344]

const SUMMON_MAP: = {15: 13, 18: 16, 24: 23, 28: 27, 31: 29, 34: 32, 42: 41, 51: 50, 53: 52, 57: 56, 59: 58, 
	62: 60, 68: 66, 73: 72, 78: 77, 82: 81, 85: 84, 91: 90, 117: 116, 130: 129, 168: 167, 169: 41, 
	199: 79, 230: 116, 262: 261, 334: 333, 405: 403, 416: 415, 462: 81, 466: 239, 553: 551, 637: 636}
const PLAIN_B: = ["chase", "charger", "ranged", "tank"]
const SUPPORT_B: = ["healer", "shielder", "summoner"]
const KEEP_DIST: = ["ranged", "fan", "beamer", "zoner", "healer", "summoner"]
const DMG_K: = 2.4
const XP_K: = 5.6
const SHINY_RATE: = 1.0 / 4096.0


const STAT_ICON: = {"hp": "heart", "atk": "fist", "spd": "boot", "cd": "clock", "def": "shield", "rgn": "sprout", "mag": "magnet", "xp": "book", "heal": "berry"}
const STAT_IDS: = ["hp", "atk", "spd", "cd", "def", "rgn", "mag", "xp", "heal"]
const STATS: = {
	"hp": {"title": "Vigor", "desc": "+20 de vida máxima (y la recupera).", "max": 9999}, 
	"atk": {"title": "Potencia", "desc": "+10% de daño con todos los movimientos.", "max": 40}, 
	"spd": {"title": "Carrera", "desc": "+7% de velocidad de movimiento.", "max": 8}, 
	"cd": {"title": "Reflejos", "desc": "-8% de recarga en todos los movimientos.", "max": 10}, 
	"def": {"title": "Coraza", "desc": "+6% de reducción de daño recibido.", "max": 12}, 
	"rgn": {"title": "Síntesis", "desc": "+0.9 de vida regenerada por segundo.", "max": 9999}, 
	"mag": {"title": "Imán", "desc": "+30% de radio de recogida de experiencia.", "max": 6}, 
	"xp": {"title": "Aprendizaje", "desc": "+12% de experiencia ganada.", "max": 8}, 
	"heal": {"title": "Baya Zidra", "desc": "Recupera el 45% de tu vida ahora mismo.", "max": 99999}, 
}

var flash_shader: Shader
var ground: Ground
var gfx: Node2D
var world: Node2D
var fx: Node2D
var player: Player
var cam: Camera2D
var hud: Hud
var stick: Stick
var slots: Slots
var cards: Cards
var enemies: Array = []
var bullets: Array = []
var orbs: Array = []
var fields: Array = []
var target: Node2D = null
var run_time: = 0.0
var kills: = 0
var spawn_acc: = 0.0
var shake: = 0.0
var death_t: = 0.0
var choosing: = false
var pending_levels: = 0
var stat_lv: = {}
var base_spd: = 100.0
var base_atk: = 1.0
var item: = ""
var sash_t: = -999.0
var bell_heal: = 0.0
var wx_kind: = ""
var wx_t: = 0.0
var wx_dur: = 0.0
var wx_check: = 60.0
var wx_chip: = 0.0
var wx_banner: = 0.0
var wx: WeatherFx
var cast_run: Array = []
var boss_run: Array = []
var boss_idx: = 0
var surge_t: = 90.0
var preload_t: = 0.0
var banner_text: = ""
var banner_t: = 0.0
var event_id: = ""
var event_t: = 0.0
var horde_defs: Array = []
var last_event: = ""
var next_event_t: = 270.0
var thief_t: = 180.0
var thieves: = 0
var hazards: Array = []
var ebullets: Array = []
var player_vel: = Vector2.ZERO
var coins: = 0
var paused: = false
var run_saved: = false
var run_bosses: = 0
var run_chests: = 0
var perks: Dictionary = {}
var rerolls: = 0
var bans: = 0
var banned: = {}
var dmg_on: = true
var shake_on: = true
var world_seed: = 0
var chunks: = {}
var player_chunk: = Vector2i(99999, 99999)
var power_kind: = ""
var power_t: = 0.0
var player_lava_t: = 0.0
var trap_slow_t: = 0.0
var tickets: = 0


func _ready() -> void :
	RenderingServer.set_default_clear_color(Color("#16233a"))
	randomize()
	L.apply()
	PXF.apply()
	Aud.setup(self)
	Aud.music("forest")
	_add_input_actions()
	flash_shader = Shader.new()
	flash_shader.code = FLASH_SHADER

	ground = Ground.new()
	ground.z_index = -3
	add_child(ground)
	gfx = Node2D.new()
	add_child(gfx)
	world = Node2D.new()
	world.y_sort_enabled = true
	add_child(world)
	fx = Node2D.new()
	add_child(fx)

	_load_data()
	_roll_run()
	surge_t = 90.0
	next_event_t = randf_range(240.0, 300.0)
	thief_t = randf_range(120.0, 240.0)
	perks = SV.perks()
	rerolls = int(perks["rerolls"])
	bans = int(perks["bans"])
	dmg_on = bool(SV.setting("dmg_numbers"))
	shake_on = bool(SV.setting("shake"))
	var sel_dex: int = SV.run_dex
	var st: Dictionary = _dex_by[sel_dex]
	player = Player.new()
	player.setup(sel_dex, _sm(sel_dex), flash_shader)
	if SV.owns(sel_dex) and bool(SV.d["owned"][str(sel_dex)]["shiny"]) and bool(SV.d["shiny_on"]):
		player.set_shiny()
	player.max_hp = float(st["hp"]) + float(perks["hp"])
	player.hp = player.max_hp
	player.spd = float(st["spd"])
	player.atk = float(st["atk"])
	player.types = st["types"]
	base_spd = player.spd * float(perks["spd"])
	base_atk = player.atk * float(perks["atk"])
	for sid in STAT_IDS:
		stat_lv[sid] = 0
	player.xp_next = float(_xp_for(1))
	var first_move: String = SV.start_move_of(sel_dex)
	player.moves = [_new_move(first_move, 1)]
	if int(perks["moves"]) >= 2:
		var cands: Array = []
		for mid in MD.ORDER:
			var md: Dictionary = MD.MOVES[mid]
			var ty: String = String(md["type"])
			if mid != first_move and String(md["kind"]) != "buff" and (ty == "normal" or player.types.has(ty)):
				cands.append(mid)
		if not cands.is_empty():
			player.moves.append(_new_move(String(cands[randi() % cands.size()]), 1))
	player.slot = 0
	world.add_child(player)
	world_seed = randi() % 100000
	_update_world(0.0)
	cam = Camera2D.new()
	player.add_child(cam)
	cam.make_current()

	var ui: = CanvasLayer.new()
	add_child(ui)
	wx = WeatherFx.new()
	ui.add_child(wx)
	hud = Hud.new()
	hud.poke_name = String(st["name"])
	ui.add_child(hud)
	stick = Stick.new()
	stick.radius = [70.0, 90.0, 120.0][clampi(int(SV.setting("stick")), 0, 2)]
	ui.add_child(stick)
	slots = Slots.new()
	ui.add_child(slots)
	slots.picked.connect(_set_active)
	cards = Cards.new()
	ui.add_child(cards)
	cards.chosen.connect(_on_card_chosen)
	cards.reroll_pressed.connect(_on_reroll)
	cards.ban_picked.connect(_on_ban)


	for i in range(3):
		_spawn_one(randf() * TAU, true)


func _add_input_actions() -> void :
	if InputMap.has_action("move_left"):
		return
	var keys: = {
		"move_left": [KEY_A, KEY_LEFT], 
		"move_right": [KEY_D, KEY_RIGHT], 
		"move_up": [KEY_W, KEY_UP], 
		"move_down": [KEY_S, KEY_DOWN], 
	}
	var dpad: = {
		"move_left": JOY_BUTTON_DPAD_LEFT, 
		"move_right": JOY_BUTTON_DPAD_RIGHT, 
		"move_up": JOY_BUTTON_DPAD_UP, 
		"move_down": JOY_BUTTON_DPAD_DOWN, 
	}
	var sticks: = {
		"move_left": [JOY_AXIS_LEFT_X, -1.0], 
		"move_right": [JOY_AXIS_LEFT_X, 1.0], 
		"move_up": [JOY_AXIS_LEFT_Y, -1.0], 
		"move_down": [JOY_AXIS_LEFT_Y, 1.0], 
	}
	for action in keys:
		InputMap.add_action(action, 0.2)
		for k in keys[action]:
			var ev: = InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action, ev)
		var b: = InputEventJoypadButton.new()
		b.button_index = dpad[action]
		InputMap.action_add_event(action, b)
		var m: = InputEventJoypadMotion.new()
		m.axis = sticks[action][0]
		m.axis_value = sticks[action][1]
		InputMap.action_add_event(action, m)


func _unhandled_input(event: InputEvent) -> void :
	var slot: = -1
	var cyc: = 0
	var go: = false
	var toggle_pause: = false
	var confirm: = false
	var cancel: = false
	var tpos: = Vector2(-1.0, -1.0)
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_1:
				slot = 0
			KEY_2:
				slot = 1
			KEY_3:
				slot = 2
			KEY_4:
				slot = 3
			KEY_Q:
				cyc = -1
			KEY_E:
				cyc = 1
			KEY_ESCAPE, KEY_P:
				toggle_pause = true
			KEY_ENTER, KEY_KP_ENTER, KEY_SPACE:
				confirm = true
			KEY_BACKSPACE, KEY_X:
				cancel = true
			_:
				go = true
	elif event is InputEventJoypadButton and event.pressed:
		match event.button_index:
			JOY_BUTTON_LEFT_SHOULDER:
				cyc = -1
			JOY_BUTTON_RIGHT_SHOULDER:
				cyc = 1
			JOY_BUTTON_START:
				toggle_pause = true
			JOY_BUTTON_A:
				confirm = true
			JOY_BUTTON_B:
				cancel = true
			_:
				go = true
	elif event is InputEventScreenTouch and event.pressed:
		go = true
		tpos = event.position
	if player.dead:
		if (go or confirm or cancel or toggle_pause or slot >= 0) and death_t > 1.0:
			_go_menu()
	elif paused:
		if toggle_pause or confirm:
			paused = false
		elif cancel:
			_abandon()
		elif tpos.x >= 0.0:
			var pr: Array = hud.pause_rects()
			if pr[1].has_point(tpos):
				paused = false
			elif pr[2].has_point(tpos):
				_abandon()
	elif not choosing:
		if toggle_pause:
			paused = true
		elif tpos.x >= 0.0 and hud.pause_rects()[0].has_point(tpos):
			paused = true
		elif slot >= 0:
			_set_active(slot)
		elif cyc != 0:
			_set_active(posmod(player.slot + cyc, player.moves.size()))


func _go_menu() -> void :
	get_tree().change_scene_to_file("res://scenes/menu.tscn")


func _finish_run() -> void :
	if run_saved:
		return
	run_saved = true
	SV.finish_run({"time": run_time, "kills": kills, "level": player.level, "bosses": run_bosses, 
		"chests": run_chests, "coins": coins, "tickets": tickets, "dex": SV.run_dex})


func _abandon() -> void :
	_finish_run()
	_go_menu()


func _on_reroll() -> void :
	if rerolls <= 0:
		return
	var picks: Array = _offer()
	if picks.is_empty():
		return
	rerolls -= 1
	var heading: String = cards.title
	var head: String = cards.headline
	cards.show_cards(picks, heading, head, true)
	cards.rerolls = rerolls
	cards.bans = bans


func _on_ban(idx: int) -> void :
	if bans <= 0 or idx < 0 or idx >= cards.items.size():
		return
	banned[String(cards.items[idx]["id"])] = true
	bans -= 1
	var picks: Array = _offer()
	if picks.is_empty():
		return
	var heading: String = cards.title
	var head: String = cards.headline
	cards.show_cards(picks, heading, head, true)
	cards.rerolls = rerolls
	cards.bans = bans


func _process(delta: float) -> void :
	hud.paused = paused
	if player.dead:
		death_t += delta
		if not run_saved:
			_finish_run()
			Aud.music("")
			Aud.sfx("gameover")
	elif not choosing and not paused:
		run_time += delta
		Aud.music("boss" if _boss_alive() else ["forest", "cave", "volcano"][mini(2, int(run_time / 360.0))])
		_update_player(delta)
		_update_world(delta)
		_update_spawner(delta)
		_update_weather(delta)
		_update_enemies(delta)
		_update_hazards(delta)
		_update_ebullets(delta)
		_update_fields(delta)
		_update_bullets(delta)
		_update_orbs(delta)
		_cleanup_enemies()
		if pending_levels > 0 and not choosing:
			_open_cards()
	ground.center = player.position
	cam.offset = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * shake * (1.0 if shake_on else 0.0)
	shake = maxf(0.0, shake - 30.0 * delta)
	hud.hp = player.hp
	hud.max_hp = player.max_hp
	hud.run_time = run_time
	hud.kills = kills
	hud.dead = player.dead
	hud.show_end = player.dead and death_t > 1.0
	hud.level = player.level
	hud.xp = player.xp
	hud.xp_next = player.xp_next
	hud.buff_text = (_buff_text() + "  " + _power_text()).strip_edges()
	hud.item_name = _item_name()
	hud.item_id = item
	hud.weather_text = _weather_text()
	hud.banner = banner_text if banner_t > 0.0 else _weather_banner()
	hud.coins = coins
	hud.tickets = tickets
	wx.kind = wx_kind
	wx.level = _wx_level()
	_refresh_slots()


func _refresh_slots() -> void :
	var info: Array = []
	for m in player.moves:
		var cdm: float = maxf(0.05, _f(m, "cd") * _cd_mul())
		info.append({
			"name": String(m["name"]), 
			"color": _col(m), 
			"lvl": int(m["lvl"]), 
			"max": _max_lvl(m), 
			"frac": clampf(1.0 - maxf(0.0, _f(m, "t")) / cdm, 0.0, 1.0), 
			"evo": bool(m["evolved"]), 
			"icon": "move:" + String(m["id"]), 
		})
	slots.info = info
	slots.active = player.slot
	slots.enabled = not choosing and not player.dead





func _lv(id: String) -> int:
	return int(stat_lv.get(id, 0))


func _buff_mul(stat: String) -> float:
	var b: Dictionary = player.buffs[stat]
	return float(b["n"]) * float(b["amount"])


func _has_item(id: String) -> bool:
	return item == id


func _item_name() -> String:
	if item == "":
		return ""
	for it in TD.ITEMS:
		if String(it["id"]) == item:
			return String(it["name"])
	return ""


func _atk() -> float:
	var k: float = 1.0
	if _has_item("choiceband"):
		k = 1.4
	elif _has_item("lifeorb"):
		k = 1.3
	return base_atk * pow(1.1, float(_lv("atk"))) * (1.0 + _buff_mul("atk")) * k * (1.5 if _pw("fury") else 1.0)


func _spd() -> float:
	var k: float = 1.35 if _has_item("choicescarf") else 1.0
	return base_spd * pow(1.07, float(_lv("spd"))) * (1.0 + _buff_mul("spd")) * k * (1.4 if _pw("haste") else 1.0)


func _cd_mul() -> float:
	var k: float = 0.8 if _has_item("quickclaw") else 1.0
	return pow(0.92, float(_lv("cd"))) * k * float(perks["cd"]) * (0.65 if _pw("frenzy") else 1.0)


func _reduction() -> float:
	var vest: float = 0.2 if _has_item("assaultvest") else 0.0
	return minf(0.8, minf(0.7, 0.06 * float(_lv("def"))) + vest + float(perks["def"]) + _buff_mul("def") + (0.4 if _pw("aegis") else 0.0))


func _regen() -> float:
	var left: float = player.max_hp * 0.015 if _has_item("leftovers") else 0.0
	return 0.9 * float(_lv("rgn")) + float(perks["regen"]) + _buff_mul("regen") + left


func _magnet() -> float:
	return BASE_MAGNET * pow(1.3, float(_lv("mag"))) * float(perks["magnet"])


func _xp_mul() -> float:
	var k: float = 1.3 if _has_item("luckyegg") else 1.0
	return pow(1.12, float(_lv("xp"))) * k * float(perks["xp"])


func _buff_text() -> String:
	var parts: Array = []
	var names: = {"atk": "ATQ", "spd": "VEL", "def": "DEF", "regen": "REG"}
	for k in names:
		var b: Dictionary = player.buffs[k]
		if int(b["n"]) > 0:
			parts.append("%s x%d" % [names[k], int(b["n"])])
	return "  ".join(parts)





func _f(m: Dictionary, key: String, def: float = 0.0) -> float:
	return float(m.get(key, def))


func _col(m: Dictionary) -> Color:
	return Color.html(String(MD.TYPE_COLOR[String(m["type"])]))


func _apply_mods(m: Dictionary, mods: Dictionary) -> void :
	for k in mods:
		if MULT_KEYS.has(k) and m.has(k):
			m[k] = float(m[k]) * float(mods[k])
		elif ADD_KEYS.has(k):
			m[k] = float(m.get(k, 0)) + float(mods[k])
		else:
			m[k] = mods[k]


func _new_move(id: String, lvl: int) -> Dictionary:
	var def: Dictionary = MD.MOVES[id]
	var m: Dictionary = def.duplicate(true)
	m["lvl"] = 1
	m["t"] = 0.0
	m["evolved"] = false
	var ladder: Array = MD.LADDERS[String(m["kind"])]
	for i in range(lvl - 1):
		_apply_mods(m, ladder[i]["m"])
		m["lvl"] = int(m["lvl"]) + 1
	return m


func _max_lvl(m: Dictionary) -> int:
	var ladder: Array = MD.LADDERS[String(m["kind"])]
	return ladder.size() + 1


func _level_up_move(m: Dictionary) -> void :
	var ladder: Array = MD.LADDERS[String(m["kind"])]
	var lv: int = int(m["lvl"])
	if lv >= _max_lvl(m):
		return
	_apply_mods(m, ladder[lv - 1]["m"])
	m["lvl"] = lv + 1



func _evo_info(m: Dictionary) -> Dictionary:
	var id: String = String(m["id"])
	var kind: String = String(m["kind"])
	if not MD.EVO.has(id) or bool(m["evolved"]) or int(m["lvl"]) < _max_lvl(m) or not MD.EVO_MODS.has(kind):
		return {}
	var e: Array = MD.EVO[id]
	var needs: String = String(e[1])
	return {
		"name": String(e[0]), 
		"needs": needs, 
		"need_name": String(MD.NEED_NAME[needs]), 
		"text": String(MD.EVO_MODS[kind]["t"]), 
		"ready": _lv(needs) > 0, 
	}


func _evolve(m: Dictionary) -> void :
	var id: String = String(m["id"])
	if not MD.EVO.has(id) or bool(m["evolved"]):
		return
	var e: Array = MD.EVO[id]
	_apply_mods(m, MD.EVO_MODS[String(m["kind"])]["m"])
	m["name"] = String(e[0])
	m["evolved"] = true
	_ring(player.position, 8.0, 120.0, Color("#ffd23f"), 0.8)
	shake = 6.0


func _set_active(i: int) -> void :
	if i < 0 or i >= player.moves.size() or i == player.slot:
		return
	if _has_item("choiceband"):
		add_text(player.position + Vector2(0.0, - player.body_h - 8.0), L.t("Cinta Elección"), Color("#ff8ad8"))
		return
	_clear_orbit_orbs()
	player.slot = i
	var m: Dictionary = player.moves[i]
	m["t"] = minf(_f(m, "t"), _f(m, "cd") * 0.35)
	_ring(player.position, 6.0, player.radius * 3.4, _col(m), 0.3)


func _clear_orbit_orbs() -> void :
	for i in range(bullets.size() - 1, -1, -1):
		if bullets[i].orb:
			bullets[i].queue_free()
			bullets.remove_at(i)





func _update_player(delta: float) -> void :
	var v: Vector2 = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if v == Vector2.ZERO and stick.axis.length() > 0.15:
		v = stick.axis
	if v.length() > 1.0:
		v = v.normalized()
	var moving: bool = v.length() > 0.05
	var spd: float = _spd() * _player_terrain(delta) * (0.55 if trap_slow_t > 0.0 else 1.0)
	var old_pos: Vector2 = player.position
	player.position += v * spd * delta
	player.position = _collide(player.position, player.radius * 0.55)
	player_vel = (player.position - old_pos) / maxf(delta, 0.0001)
	player.invuln = maxf(0.0, player.invuln - delta)
	if bell_heal > 0.0:
		var bh: float = minf(bell_heal, 4.0 * delta)
		player.hp = minf(player.max_hp, player.hp + bh)
		bell_heal -= bh
	var reg: float = _regen()
	if reg > 0.0:
		player.hp = minf(player.max_hp, player.hp + reg * delta)
	player.attack_face = maxf(0.0, player.attack_face - delta)

	for k in player.buffs:
		var b: Dictionary = player.buffs[k]
		if int(b["n"]) > 0:
			b["t"] = float(b["t"]) - delta
			if float(b["t"]) <= 0.0:
				b["n"] = 0

	target = _nearest_enemy(player.position, AIM_REACH)
	if target != null:
		player.aim = (target.position - player.position).angle()
	elif moving:
		player.aim = v.angle()

	var face: float = player.aim
	if moving and player.attack_face <= 0.0:
		face = v.angle()
	player.face_angle(face)
	if moving:
		player.loop_anim("Walk", spd / 110.0)
	else:
		player.loop_anim("Idle", 1.0)

	var m: Dictionary = player.moves[player.slot]
	_tick_move(m, delta)


func _hurt_player(amount: float, atk_type: String = "") -> void :
	if player.invuln > 0.0 or player.dead:
		return
	var eff: String = ""
	if atk_type != "":
		var tk: float = _types_mult(atk_type, player.types)
		amount *= tk * _weather_mult(atk_type)
		eff = _eff_label(tk)
	var close: float = 1.0
	if String(player.moves[player.slot]["kind"]) == "melee":
		close = 0.75
	var d: float = maxf(1.0, amount * (1.0 - _reduction()) * close)
	player.hp -= d
	player.invuln = 0.45
	Aud.sfx("hurt")
	if bool(SV.setting("vibration")):
		Input.vibrate_handheld(40)
	player.flash = 0.6
	shake = 5.0
	var tcol: = Color("#ff6b7a")
	if eff == "super":
		tcol = Color("#ff3048")
	elif eff == "weak":
		tcol = Color("#c9a0a8")
	add_text(player.position + Vector2(0.0, - player.body_h - 4.0), "-" + str(roundi(d)), tcol, 24 if eff == "super" else 18)

	if player.hp <= 0.0 and _has_item("focussash") and run_time - sash_t > 60.0:
		sash_t = run_time
		player.hp = 1.0
		player.invuln = 1.2
		add_text(player.position + Vector2(0.0, - player.body_h - 20.0), L.t("¡Banda Focus!"), Color("#ff9a3d"), 24)
		_ring(player.position, 6.0, 70.0, Color("#ff9a3d"), 0.5)
	if player.hp <= 0.0:
		player.hp = 0.0
		player.dead = true
		player.sprite.modulate = Color(1, 1, 1, 0.5)
		player.active = false
		_clear_orbit_orbs()
		for e in enemies:
			e.active = false





func _reach(m: Dictionary) -> float:
	var k: String = String(m["kind"])
	if k == "melee":
		return _f(m, "radius") + 30.0
	if k == "beam":
		return _f(m, "radius") + 20.0
	if k == "boomerang":
		return _f(m, "radius") + 40.0
	if k == "chain":
		return 280.0
	if k == "meteor":
		return 340.0
	if k == "dash":
		return _f(m, "radius") + 60.0
	if k == "cone":
		return _f(m, "speed") * _f(m, "life") + 30.0
	return 520.0


func _tick_move(m: Dictionary, delta: float) -> void :
	var kind: String = String(m["kind"])
	if kind == "orbit":
		_orbit(m, delta)
		return
	m["t"] = _f(m, "t") - delta
	if _f(m, "t") > 0.0:
		return

	if TARGETED.has(kind):
		if target == null or player.position.distance_to(target.position) > _reach(m):
			m["t"] = 0.05
			return
	var cd: float = maxf(0.05, _f(m, "cd") * _cd_mul())
	m["t"] = cd
	if _has_item("lifeorb") and kind != "trail":
		player.hp = maxf(1.0, player.hp - maxf(1.0, player.max_hp * 0.01))
	if m.has("iframes"):
		player.invuln = maxf(player.invuln, float(m["iframes"]))
	if kind != "trail":
		player.attack_face = 0.35
		player.play_attack(String(ANIM_FOR.get(kind, "Shoot")), maxf(0.12, cd))
	Aud.shot(kind, String(m.get("type", "normal")))
	match kind:
		"projectile":
			_fire_projectiles(m)
		"melee":
			_melee(m)
		"beam":
			_beam(m)
		"nova":
			_nova(m)
		"aura":
			_aura(m)
		"buff":
			_buff(m)
		"boomerang":
			_boomerang(m)
		"chain":
			_chain(m)
		"mine":
			_mines(m)
		"meteor":
			_meteors(m)
		"turret":
			_turret(m)
		"dash":
			_dash(m)
		"trail":
			_trail_patch(m)
		"cone":
			_cone(m)


func _make_bullet(m: Dictionary, pos: Vector2, vel: Vector2, life: float, pierce: int) -> Bullet:
	var b: = Bullet.new()
	b.position = pos
	b.ppos = pos
	b.vel = vel
	b.dmg = _f(m, "dmg") * _atk()
	b.r = _f(m, "size", 6.0)
	b.life = life
	b.pierce = pierce
	b.color = _col(m)
	b.homing = _f(m, "homing")
	b.burn = int(_f(m, "burn"))
	b.poison = int(_f(m, "poison"))
	b.slow = _f(m, "slow")
	b.knock = _f(m, "knock")
	b.mtype = String(m["type"])
	fx.add_child(b)
	bullets.append(b)
	return b


func _fire_projectiles(m: Dictionary) -> void :
	var n: int = maxi(1, int(_f(m, "count", 1.0)))
	var spread: float = _f(m, "spread")
	for i in range(n):
		var off: float = 0.0
		if n > 1:
			off = (float(i) / float(n - 1) - 0.5) * spread * float(n)
		var a: float = player.aim + off + randf_range(-0.03, 0.03)
		var d: Vector2 = Vector2.from_angle(a)
		_make_bullet(m, player.position + d * 3.0, d * _f(m, "speed"), _f(m, "life", 1.4), int(_f(m, "pierce")))


func _nova(m: Dictionary) -> void :
	var n: int = maxi(3, int(_f(m, "count", 8.0)))
	for i in range(n):
		var a: float = float(i) / float(n) * TAU + randf_range(-0.06, 0.06)
		var d: Vector2 = Vector2.from_angle(a)
		_make_bullet(m, player.position + d * 3.0, d * _f(m, "speed"), _f(m, "life", 1.2), int(_f(m, "pierce")))
	_ring(player.position, player.radius, player.radius * 4.0, _col(m), 0.3)


func _cone(m: Dictionary) -> void :
	var n: int = maxi(2, int(_f(m, "count", 5.0)))
	var arc: float = _f(m, "arc", 0.9)
	for i in range(n):
		var a: float = player.aim + (float(i) / float(n - 1) - 0.5) * arc + randf_range(-0.05, 0.05)
		var sp: float = _f(m, "speed") * randf_range(0.85, 1.1)
		var d: Vector2 = Vector2.from_angle(a)
		_make_bullet(m, player.position + d * 4.0, d * sp, _f(m, "life", 0.5) * randf_range(0.85, 1.05), int(_f(m, "pierce")))


func _boomerang(m: Dictionary) -> void :
	var n: int = maxi(1, int(_f(m, "count", 1.0)))
	var spread: float = _f(m, "spread", 0.5)
	var out: float = _f(m, "radius") / maxf(1.0, _f(m, "speed"))
	for i in range(n):
		var off: float = 0.0
		if n > 1:
			off = (float(i) / float(n - 1) - 0.5) * spread * float(minf(float(n), 3.0))
		var d: Vector2 = Vector2.from_angle(player.aim + off)
		var b: Bullet = _make_bullet(m, player.position, d * _f(m, "speed"), out * 4.0 + 1.5, 999)
		b.boom = out
		b.bsp = _f(m, "speed") * 1.1


func _in_arc(from: Vector2, p: Vector2, aim: float, half: float) -> bool:
	var a: float = (p - from).angle()
	return absf(fposmod(a - aim + PI * 3.0, TAU) - PI) <= half


func _melee(m: Dictionary) -> void :
	var rad: float = _f(m, "radius")
	var arc: float = _f(m, "arc", 1.6)
	var half: float = minf(arc, TAU) * 0.5
	var f: = Fx.new()
	f.kind = "arc"
	f.color = _col(m)
	f.position = player.position
	f.ang = player.aim
	f.arc = minf(arc, TAU)
	f.r1 = rad
	f.life = 0.18
	fx.add_child(f)
	for e in enemies:
		if e.dead:
			continue
		if e.position.distance_to(player.position) > rad + e.radius * 0.5:
			continue
		if not _in_arc(player.position, e.position, player.aim, half):
			continue
		_hit_move(e, _f(m, "dmg") * _atk(), e.position - player.position, m)


func _beam(m: Dictionary) -> void :
	var ln: float = _f(m, "radius")
	var w: float = _f(m, "width", 30.0)
	var d: Vector2 = Vector2.from_angle(player.aim)
	var f: = Fx.new()
	f.kind = "beam"
	f.color = _col(m)
	f.position = player.position
	f.ang = player.aim
	f.length = ln
	f.width = w
	f.life = 0.2
	fx.add_child(f)
	shake = maxf(shake, 1.5)
	for e in enemies:
		if e.dead:
			continue
		var rel: Vector2 = e.position - player.position
		var along: float = rel.dot(d)
		if along < - e.radius or along > ln + e.radius:
			continue
		var side: float = absf( - rel.x * d.y + rel.y * d.x)
		if side <= w * 0.5 + e.radius:
			_hit_move(e, _f(m, "dmg") * _atk(), d, m)


func _aura(m: Dictionary) -> void :
	var rad: float = _f(m, "radius")
	_ring(player.position, rad * 0.5, rad, _col(m), 0.28)
	for e in enemies:
		if e.dead:
			continue
		if e.position.distance_to(player.position) <= rad + e.radius * 0.5:
			_hit_move(e, _f(m, "dmg") * _atk(), e.position - player.position, m)


func _buff(m: Dictionary) -> void :
	var stat: String = String(m["stat"])
	if player.buffs.has(stat):
		var b: Dictionary = player.buffs[stat]
		b["amount"] = _f(m, "amount")
		b["n"] = mini(int(_f(m, "stacks")), int(b["n"]) + 1)
		b["t"] = _f(m, "dur")
	_ring(player.position, player.radius * 2.4, player.radius * 1.1, _col(m), 0.35)


func _chain(m: Dictionary) -> void :
	var cur: Node2D = null
	if target != null and not target.dead and player.position.distance_to(target.position) <= _reach(m):
		cur = target
	else:
		cur = _nearest_enemy(player.position, _reach(m))
	if cur == null:
		return
	var from: Vector2 = player.position + Vector2(0.0, - LIFT)
	var k: float = 1.0
	var done: = {}
	var n: int = maxi(1, int(_f(m, "count", 1.0)))
	var jump: float = _f(m, "radius", 140.0)
	for i in range(n):
		if cur == null:
			break
		done[cur.get_instance_id()] = true
		var to: Vector2 = cur.position + Vector2(0.0, - cur.body_h * 0.5)
		var f: = Fx.new()
		f.kind = "line"
		f.color = _col(m)
		f.position = from
		f.p2 = to - from
		f.width = 5.0
		f.life = 0.2
		fx.add_child(f)
		var hex: float = 1.0
		if m.has("hex") and (cur.burn > 0 or cur.poison > 0 or cur.slow > 0.0):
			hex = _f(m, "hex")
		_hit_move(cur, _f(m, "dmg") * _atk() * k * hex, to - from, m)
		k *= 0.85
		from = to
		var best: Node2D = null
		var bd: float = jump * jump
		for e in enemies:
			if e.dead or done.has(e.get_instance_id()):
				continue
			var d2: float = cur.position.distance_squared_to(e.position)
			if d2 < bd:
				bd = d2
				best = e
		cur = best
	shake = maxf(shake, 1.0)


func _new_field(kind: String, m: Dictionary, pos: Vector2) -> Field:
	var f: = Field.new()
	f.kind = kind
	f.move = m
	f.color = _col(m)
	f.position = pos
	f.dmg = _f(m, "dmg") * _atk()
	if kind == "turret":
		world.add_child(f)
	else:
		gfx.add_child(f)
	fields.append(f)
	return f


func _trim_fields(kind: String, keep: int) -> void :
	var mine: Array = []
	for f in fields:
		if f.kind == kind and not f.gone:
			mine.append(f)
	var extra: int = mine.size() - keep
	for i in range(maxi(0, extra)):
		mine[i].gone = true


func _mines(m: Dictionary) -> void :
	var n: int = maxi(1, int(_f(m, "count", 1.0)))
	for i in range(n):
		var a: float = randf() * TAU
		var d: float = 0.0
		if n > 1:
			d = randf_range(18.0, 46.0)
		var f: Field = _new_field("mine", m, player.position + Vector2(cos(a) * d, sin(a) * d * 0.8))
		f.arm = 0.35
		f.life = _f(m, "dur", 7.0)
		f.r = _f(m, "radius")
	_trim_fields("mine", 4 + n * 2)


func _meteors(m: Dictionary) -> void :
	var n: int = maxi(1, int(_f(m, "count", 1.0)))
	var near: Array = []
	for e in enemies:
		if not e.dead and e.position.distance_to(player.position) <= _reach(m):
			near.append(e)
	near.shuffle()
	for i in range(n):
		var pos: Vector2
		if i < near.size():
			pos = near[i].position + Vector2(randf_range(-8.0, 8.0), randf_range(-6.0, 6.0))
		else:
			pos = player.position + Vector2(randf_range(-140.0, 140.0), randf_range(-110.0, 110.0))
		var f: Field = _new_field("meteor", m, pos)
		f.t = - float(i) * 0.09
		f.fall = 0.5
		f.r = _f(m, "radius")


func _turret(m: Dictionary) -> void :
	var a: float = player.aim + PI + randf_range(-0.6, 0.6)
	var f: Field = _new_field("turret", m, player.position + Vector2(cos(a) * 26.0, sin(a) * 20.0))
	f.life = _f(m, "dur", 6.0)
	f.shot_t = 0.3
	_trim_fields("turret", maxi(1, int(_f(m, "count", 1.0))))
	_ring(player.position, 4.0, 30.0, _col(m), 0.3)


func _dash(m: Dictionary) -> void :
	var d: Vector2 = Vector2.from_angle(player.aim)
	var start: Vector2 = player.position
	var ln: float = _f(m, "radius")
	var w: float = _f(m, "width", 34.0)
	var dest: Vector2 = start + d * ln
	for s in range(0, int(ln) + 1, 22):
		var f: = Fx.new()
		f.kind = "burst"
		f.color = _col(m)
		f.position = start + d * float(s)
		f.r1 = 10.0
		f.life = 0.22
		fx.add_child(f)
	var sl: = Fx.new()
	sl.kind = "arc"
	sl.color = _col(m)
	sl.position = dest
	sl.ang = player.aim
	sl.arc = 2.2
	sl.r1 = 34.0
	sl.life = 0.18
	fx.add_child(sl)
	player.position = dest
	player.invuln = maxf(player.invuln, _f(m, "iframes", 0.3))
	for e in enemies:
		if e.dead:
			continue
		var cp: Vector2 = Geometry2D.get_closest_point_to_segment(e.position, start, dest)
		var rr: float = w * 0.5 + e.radius
		if cp.distance_squared_to(e.position) <= rr * rr:
			_hit_move(e, _f(m, "dmg") * _atk(), d, m)
	shake = maxf(shake, 3.0)


func _trail_patch(m: Dictionary) -> void :
	var rad: float = _f(m, "radius")

	if player.last_patch != null and is_instance_valid(player.last_patch):
		var last: Field = player.last_patch
		if last.position.distance_squared_to(player.position) < pow(rad * 0.9, 2.0) and last.t < 1.0:
			return
	var f: Field = _new_field("patch", m, player.position)
	f.life = _f(m, "dur", 3.0)
	f.r = rad
	f.tick = 0.0
	player.last_patch = f
	_trim_fields("patch", 18)


func _orbit(m: Dictionary, delta: float) -> void :
	var want: int = maxi(1, int(_f(m, "count", 1.0)))
	var mid: String = String(m["id"])
	var mine: Array = []
	for ob in bullets:
		if ob.orb and ob.mid == mid:
			mine.append(ob)
	var relayout: bool = mine.size() != want
	var base_a: float = run_time * _f(m, "speed")
	if mine.size() > 0:
		base_a = mine[0].oa
	while mine.size() > want:
		var ex = mine.pop_back()
		ex.queue_free()
		bullets.erase(ex)
	for i in range(mine.size(), want):
		var nb: = Bullet.new()
		nb.orb = true
		nb.mid = mid
		nb.oa = float(i) / float(want) * TAU
		nb.life = 1000000000.0
		nb.pierce = 999999
		nb.position = player.position
		fx.add_child(nb)
		bullets.append(nb)
		mine.append(nb)
	for i in range(mine.size()):
		var ob = mine[i]
		ob.dmg = _f(m, "dmg") * _atk()
		ob.orad = _f(m, "radius")
		ob.ospeed = _f(m, "speed")
		ob.r = _f(m, "size", 8.0)
		ob.color = _col(m)
		ob.rehit = maxf(0.12, _f(m, "cd"))
		ob.knock = _f(m, "knock")
		ob.burn = int(_f(m, "burn"))
		ob.poison = int(_f(m, "poison"))
		ob.slow = _f(m, "slow")
		ob.mtype = String(m["type"])
		if relayout:
			ob.oa = base_a + float(i) / float(mine.size()) * TAU
	player.orb_cast_t -= delta
	if player.orb_cast_t <= 0.0:
		player.orb_cast_t = 1.6
		player.play_attack("Shoot", 1.6)



func _types_mult(atk: String, defs: Array) -> float:
	if not TD.CHART.has(atk):
		return 1.0
	var row: Dictionary = TD.CHART[atk]
	var m: float = 1.0
	for t in defs:
		if row.has(t):
			var v: float = float(row[t])
			if v > 1.0:
				m *= 1.6
			elif v > 0.0:
				m *= 0.6
			else:
				m *= 0.3
	return clampf(m, 0.3, 2.4)


func _eff_label(k: float) -> String:
	if k > 1.05:
		return "super"
	if k < 0.95:
		return "weak"
	return ""


func _type_mult(mtype: String, e) -> float:
	return _types_mult(mtype, e.types) * _weather_mult(mtype)


func _hit_move(e, dmg: float, dir: Vector2, m: Dictionary) -> void :
	_hit_enemy(e, dmg, _col(m), dir, _f(m, "knock"), String(m["type"]), 
		int(_f(m, "burn")), int(_f(m, "poison")), _f(m, "slow"))


func _hit_enemy(e, dmg: float, col: Color, dir: Vector2, knock: float, mtype: String, burn: int, poison: int, slow: float) -> void :
	var eff: String = _eff_label(_types_mult(mtype, e.types))
	var d_final: float = dmg * _type_mult(mtype, e)
	if float(perks["crit"]) > 0.0 and randf() < float(perks["crit"]):
		d_final *= 1.5
		add_text(e.position + Vector2(0.0, - e.body_h - 26.0), L.t("¡Crítico!"), Color("#ffb347"), 16)
	if _has_item("shellbell"):
		bell_heal = minf(4.0, bell_heal + d_final * 0.04)
	_damage_enemy(e, d_final, col, dir, knock, eff)
	if e.dead:
		return
	if burn > 0:
		e.apply_burn(burn)
	if poison > 0:
		e.apply_poison(poison)
	if slow > 0.0:
		e.apply_slow(slow)


func _ring(pos: Vector2, r0: float, r1: float, color: Color, life: float) -> void :
	var f: = Fx.new()
	f.kind = "ring"
	f.color = color
	f.position = pos
	f.r0 = r0
	f.r1 = r1
	f.life = life
	fx.add_child(f)





func _blast(f: Field, r: float, k: float) -> void :
	var m: Dictionary = f.move
	for e in enemies:
		if e.dead:
			continue
		if e.position.distance_to(f.position) <= r + e.radius * 0.5:
			_hit_move(e, f.dmg * k, e.position - f.position, m)


func _update_fields(delta: float) -> void :
	for i in range(fields.size() - 1, -1, -1):
		var f: Field = fields[i]
		f.t += delta
		if f.gone or (f.life > 0.0 and f.t >= f.life and f.kind != "mine"):
			f.queue_free()
			fields.remove_at(i)
			continue
		var m: Dictionary = f.move
		if f.kind == "mine":
			var trig: bool = false
			if f.t >= f.arm:
				for e in enemies:
					if not e.dead and e.position.distance_to(f.position) <= 14.0 + e.radius * 0.5:
						trig = true
						break
			if trig or f.t >= f.life:
				_ring(f.position, 4.0, f.r, f.color, 0.3)
				shake = maxf(shake, 2.0)
				_blast(f, f.r, 1.0 if trig else 0.5)
				f.queue_free()
				fields.remove_at(i)
		elif f.kind == "meteor":
			if f.t >= f.fall:
				_ring(f.position, 4.0, f.r, f.color, 0.35)
				shake = maxf(shake, 4.0)
				_blast(f, f.r, 1.0)
				f.queue_free()
				fields.remove_at(i)
		elif f.kind == "turret":
			f.shot_t -= delta
			if f.shot_t <= 0.0:
				var tg: Node2D = _nearest_enemy(f.position, _f(m, "range", 300.0))
				f.shot_t = 0.15
				if tg != null:
					f.shot_t = _f(m, "rate", 0.6)
					var d: Vector2 = (tg.position - f.position).normalized()
					var b: Bullet = _make_bullet(m, f.position, d * _f(m, "speed", 300.0), 1.4, int(_f(m, "pierce")))
					b.dmg = f.dmg
					b.r = _f(m, "size", 6.0)
					f.kick = 0.12
			if f.kick > 0.0:
				f.kick -= delta
		elif f.kind == "patch":
			f.tick -= delta
			if f.tick <= 0.0:
				f.tick = 0.5
				_blast(f, f.r, 1.0)





static var _dex_list: Array = []
static var _dex_by: Dictionary = {}
static var _smeta: Dictionary = {}


func _load_data() -> void :
	SV.ensure()
	_dex_list = SV.dex_list
	_dex_by = SV.dex_by
	_smeta = SV.smeta


func _sm(dex: int) -> Dictionary:
	return _smeta[str(dex)]



func _hash(x: int, y: int, seed_v: int) -> float:
	var h: int = ((x & 4294967295) * 374761393) & 4294967295
	h = h ^ (((y & 4294967295) * 668265263) & 4294967295)
	h = h ^ (((seed_v & 4294967295) * 2246822519) & 4294967295)
	h = ((h ^ (h >> 13)) * 1274126177) & 4294967295
	h = h ^ (h >> 16)
	return float(h & 4294967295) / 4294967300.0


func _pick_n(arr: Array, n: int) -> Array:
	var c: Array = arr.duplicate()
	c.shuffle()
	return c.slice(0, mini(n, c.size()))


func _has_t(types: Array, xs: Array) -> bool:
	for x in xs:
		if types.has(x):
			return true
	return false


func _base_hp(p: Dictionary) -> float:
	return (float(p["hp"]) - 70.0) / 0.45


func _base_spd(p: Dictionary) -> float:
	return (float(p["spd"]) - 78.0) / 0.42


static var _beh_cache: Dictionary = {}


func _behavior_of(p: Dictionary) -> String:
	var dex: int = int(p["dex"])
	if _beh_cache.has(dex):
		return String(_beh_cache[dex])
	var r: String = _behavior_calc(p)
	_beh_cache[dex] = r
	return r


func _behavior_calc(p: Dictionary) -> String:
	var dex: int = int(p["dex"])
	var t: Array = p["types"]
	var h: float = _hash(dex, 7, 11)
	if HEAL_SET.has(dex):
		return "healer"
	if SHIELD_SET.has(dex):
		return "shielder"
	if BOMB_SET.has(dex):
		return "bomber"
	if SUMMON_MAP.has(dex) and _smeta.has(str(SUMMON_MAP[dex])):
		return "summoner"
	if _has_t(t, ["bug"]) and h >= 0.6 and h < 0.78:
		return "summoner"
	if _has_t(t, ["electric", "psychic", "dragon", "ice"]) and h < 0.18:
		return "beamer"
	if _has_t(t, ["fire", "ground", "poison"]) and h < 0.18:
		return "zoner"
	if _has_t(t, ["water", "grass", "bug", "fairy"]) and h >= 0.18 and h < 0.32:
		return "fan"
	if _has_t(t, ["fighting", "ground", "normal", "rock"]) and h >= 0.42 and h < 0.56:
		return "jumper"
	if _has_t(t, ["psychic", "electric", "ghost", "fairy"]) and h < 0.4:
		return "ranged"
	if _has_t(t, ["fire", "water", "poison", "ice"]) and h < 0.22:
		return "ranged"
	if _has_t(t, ["fighting", "normal", "ground", "rock", "dragon", "steel", "dark"]) and h < 0.4:
		return "charger"
	if _base_hp(p) > 95.0 and _base_spd(p) < 50.0:
		return "tank"
	return "chase"


func _def_for(p: Dictionary, tier: Dictionary, ti: int) -> Dictionary:
	var hp_k: float = clampf(_base_hp(p) / 65.0, 0.7, 1.6)
	var spd_k: float = clampf(0.75 + _base_spd(p) / 260.0, 0.75, 1.3)
	var b: String = _behavior_of(p)
	var tank: bool = b == "tank"
	var d: = {
		"dex": int(p["dex"]), "name": String(p["name"]), "behavior": b, 
		"hp": roundf(float(tier["hp"]) * hp_k * (1.5 if tank else 1.0)), 
		"spd": roundf(float(tier["spd"]) * spd_k * (0.7 if tank else 1.0)), 
		"dmg": roundf(float(tier["dmg"]) * (1.2 if tank else 1.0)), 
		"xp": maxf(3.0, roundf(float(tier["xp"]) * (1.3 if tank else 1.0))), 
	}
	var cds: = {"ranged": 2.2 - float(ti) * 0.15, "fan": 3.2 - float(ti) * 0.15, "beamer": 4.4 - float(ti) * 0.2, 
		"zoner": 4.6 - float(ti) * 0.2, "healer": 3.5, "summoner": 7.0}
	if cds.has(b):
		d["shotDmg"] = roundf(float(tier["dmg"]) * (0.7 if b == "fan" else 0.8))
		d["shotCd"] = snappedf(float(cds[b]), 0.01)
		var rg: float = 190.0
		if b == "beamer":
			rg = 260.0
		elif b == "healer" or b == "summoner":
			rg = 230.0
		d["range"] = rg + float(ti) * 6.0
	if b == "summoner":
		d["minion"] = int(SUMMON_MAP.get(int(p["dex"]), int(p["dex"])))
	if b == "fan":
		d["fanN"] = 3 if ti < 2 else 5
	if b == "zoner":
		d["zones"] = 1 if ti < 2 else (2 if ti < 4 else 3)
	if b == "bomber":
		d["spd"] = roundf(float(d["spd"]) * 1.25)
		d["hp"] = roundf(float(d["hp"]) * 0.8)
	return d


static var _cand_cache: Dictionary = {}


func _candidates(ti: int) -> Array:
	if _cand_cache.has(ti):
		return _cand_cache[ti]
	var tier: Dictionary = TIERS[ti]
	var lo: float = float(tier["bst"][0])
	var hi: float = float(tier["bst"][1])
	var out: Array = []
	for p in _dex_list:
		if int(p["rarity"]) < 5 and float(p["bst"]) >= lo and float(p["bst"]) <= hi and _smeta.has(str(int(p["dex"]))):
			out.append(p)
	_cand_cache[ti] = out
	return out


func _cast_for(ti: int) -> Array:
	var tier: Dictionary = TIERS[ti]
	var all: Array = _candidates(ti)
	var kinds: Array = []
	for k in SUPPORT_B:
		for p in all:
			if _behavior_of(p) == k:
				kinds.append(k)
				break
	var pick: Array = []
	if not kinds.is_empty():
		var sk: String = String(kinds[randi() % kinds.size()])
		var pool_s: Array = []
		for p in all:
			if _behavior_of(p) == sk:
				pool_s.append(p)
		pick = _pick_n(pool_s, 1)
	var need: int = int(tier["cast"])
	if int(tier["from"]) > 0:
		var pool_x: Array = []
		for p in all:
			var bb: String = _behavior_of(p)
			if not PLAIN_B.has(bb) and not SUPPORT_B.has(bb):
				pool_x.append(p)
		pick.append_array(_pick_n(pool_x, 1))
	var rest: Array = []
	for p in all:
		if pick.has(p):
			continue
		if int(tier["from"]) == 0 and not PLAIN_B.has(_behavior_of(p)):
			continue
		rest.append(p)
	pick.append_array(_pick_n(rest, need - pick.size()))
	return pick


func _roll_run() -> void :
	cast_run = []
	for ti in range(TIERS.size()):
		var list: Array = []
		for p in _cast_for(ti):
			list.append(_def_for(p, TIERS[ti], ti))
		cast_run.append({"from": int(TIERS[ti]["from"]), "list": list})

	for tier in cast_run:
		var best: Dictionary = {}
		for d in tier["list"]:
			var bb: String = String(d["behavior"])
			if bb == "chase" or bb == "charger" or bb == "tank":
				if best.is_empty() or float(d["spd"]) > float(best["spd"]):
					best = d
		if not best.is_empty():
			best["behavior"] = "runner"
			best["spd"] = roundf(float(best["spd"]) * 1.6)
			best["hp"] = roundf(float(best["hp"]) * 0.7)
	boss_run = []
	var used: = {}
	for slot in BOSS_SLOTS:
		var pool: Array = []
		for p in _dex_list:
			var dx: int = int(p["dex"])
			if bool(p.get("leg", false)) or not _smeta.has(str(dx)) or used.has(dx):
				continue
			if float(p["bst"]) >= float(slot["bst"][0]) and float(p["bst"]) <= float(slot["bst"][1]):
				pool.append(p)
		if pool.is_empty():
			for p in _dex_list:
				var dx2: int = int(p["dex"])
				if not bool(p.get("leg", false)) and _smeta.has(str(dx2)) and not used.has(dx2) and float(p["bst"]) >= 580.0:
					pool.append(p)
		var bp: Dictionary = pool[randi() % pool.size()]
		used[int(bp["dex"])] = true
		var bb2: String = "chase"
		if _behavior_of(bp) == "ranged":
			bb2 = "ranged"
		elif _base_spd(bp) > 90.0:
			bb2 = "charger"
		boss_run.append({
			"at": float(slot["at"]), "dex": int(bp["dex"]), "name": String(bp["name"]), 
			"hp": roundf(float(slot["hp"]) * 1.35), "spd": roundf(clampf(40.0 + _base_spd(bp) * 0.5, 40.0, 100.0)), 
			"dmg": roundf(float(slot["dmg"]) * 1.2), "xp": float(slot["xp"]), "behavior": bb2, 
			"shotDmg": roundf(float(slot["dmg"]) * 0.55), "shotCd": 1.1, "range": 260.0, 
		})


func _tier_at(t: float) -> int:
	var ti: int = 0
	for i in range(TIERS.size()):
		if t >= float(TIERS[i]["from"]):
			ti = i
	return ti


func _bag_at(t: float) -> Array:
	if event_id == "horde" and not horde_defs.is_empty():
		return horde_defs
	var bag: Array = []
	for tier in cast_run:
		if t < float(tier["from"]):
			continue
		var w: int = 3 if t - float(tier["from"]) > 260.0 else 10
		for d in tier["list"]:
			for i in range(w):
				bag.append(d)
	if bag.is_empty():
		return cast_run[0]["list"]
	return bag


func _hp_k(t: float) -> float:
	return 3.3 + minf(1.7, t / 210.0)


func _scale_at(t: float) -> Dictionary:
	return {"hp": 1.0 + t / 95.0, "dmg": 1.0 + t / 420.0, "spd": 1.0 + minf(0.35, t / 1400.0)}


func _boss_scale_k(dex: int) -> float:
	var idle: Dictionary = _sm(dex)["a"]["Idle"] if _sm(dex)["a"].has("Idle") else _sm(dex)["a"]["Walk"]
	var h: float = float(idle["ay"]) * 2.0
	return clampf(roundf(110.0 / h * 2.0) / 2.0, 1.0, 2.0)


func _say(text: String, secs: float = 2.6) -> void :
	banner_text = L.t(text)
	banner_t = secs


func _make_enemy(def: Dictionary, pos: Vector2, sc: Dictionary, boss: bool = false) -> Enemy:
	var dex: int = int(def["dex"])
	var p: Dictionary = _dex_by[dex]
	var sm: Dictionary = _sm(dex)
	var e: = Enemy.new()
	var scl: float = _boss_scale_k(dex) if boss else 1.0
	e.setup(dex, sm, flash_shader, scl, false)
	e.def = def
	e.boss = boss
	e.behavior = String(def["behavior"])
	e.enemy_name = String(p["name"])
	var ty: Array = p["types"]
	e.types = ty if not ty.is_empty() else ["normal"]
	e.atk_type = String(e.types[0])
	e.flying = boss or bool(sm.get("hv", 0))
	e.max_hp = roundf(float(def["hp"]) * float(sc["hp"]))
	e.hp = e.max_hp
	e.spd = float(def["spd"]) * float(sc["spd"])
	e.dmg = float(def["dmg"]) * float(sc["dmg"])
	e.xp_val = float(def["xp"])
	e.sc = sc
	if def.has("shotCd"):
		e.shot_cd = randf_range(0.3, float(def["shotCd"]))
	e.skill_cd = randf_range(1.0, 4.0)
	e.bob = randf() * TAU
	e.position = pos
	world.add_child(e)
	enemies.append(e)
	return e


func _ring_point(angle: float) -> Vector2:
	var d: float = get_viewport_rect().size.length() * 0.5 + randf_range(10.0, 70.0)
	return player.position + Vector2(cos(angle) * d, sin(angle) * d * 0.9)


func _spawn_one(angle: float = -999.0, near: bool = false) -> Enemy:
	var bag: Array = _bag_at(run_time)
	var def: Dictionary = bag[randi() % bag.size()]
	var a: float = angle if angle > -900.0 else randf() * TAU
	var pos: Vector2 = _ring_point(a)
	if near:
		pos = player.position + Vector2.from_angle(a) * randf_range(380.0, 520.0)
	pos = _free_spot(pos, 14.0)
	var base: Dictionary = _scale_at(run_time)
	var sc: = {"hp": float(base["hp"]) * _hp_k(run_time), "dmg": base["dmg"], "spd": base["spd"]}
	var e: Enemy = _make_enemy(def, pos, sc)
	e.dmg *= DMG_K
	e.xp_val = roundf(e.xp_val * XP_K)
	if enemies.size() >= int(ENEMY_CAP * 0.85):
		e.max_hp = roundf(e.max_hp * 1.6)
		e.hp = e.max_hp
		e.dmg *= 1.25
		e.xp_val = roundf(e.xp_val * 1.6)
	if bool(_sm(e.dex).get("sh", 0)) and randf() < SHINY_RATE:
		e.make_shiny()
		Aud.sfx("shiny")
		_say(L.t("¡Un %s shiny anda cerca!") % e.enemy_name, 3.4)
	if event_id == "gold":
		e.make_golden()
	return e


func _spawn_boss(b: Dictionary) -> void :
	var t: float = run_time
	var sc: = {"hp": 1.0 + t / 600.0, "dmg": 1.0 + t / 600.0, "spd": 1.0}
	var e: Enemy = _make_enemy(b, _ring_point(randf() * TAU), sc, true)
	if bool(_sm(e.dex).get("sh", 0)) and randf() < SHINY_RATE:
		e.make_shiny()
	Aud.sfx("boss")
	_say(L.t("¡%s%s salvaje apareció!") % [e.enemy_name, " shiny" if e.shiny else ""], 3.2)
	shake = 14.0


func _boss_alive() -> bool:
	for e in enemies:
		if e.boss and not e.dead:
			return true
	return false


func _update_spawner(delta: float) -> void :

	var t: float = run_time
	banner_t = maxf(0.0, banner_t - delta)

	if boss_idx < boss_run.size() and t >= float(boss_run[boss_idx]["at"]):
		_spawn_boss(boss_run[boss_idx])
		boss_idx += 1
	var fight: bool = _boss_alive()
	if enemies.size() < ENEMY_CAP:
		var rate: float = (1.6 + t * 0.028 + pow(t / 60.0, 1.6) * 0.5) * 0.17
		spawn_acc += rate * (0.25 if fight else 1.0) * delta
		while spawn_acc >= 1.0:
			spawn_acc -= 1.0
			if enemies.size() < ENEMY_CAP:
				_spawn_one()

	if not fight:
		surge_t -= delta
	if surge_t <= 0.0:
		surge_t = randf_range(38.0, 56.0)
		var base_a: float = randf() * TAU
		var n: int = mini(ENEMY_CAP - enemies.size(), roundi(float(14 + int(t / 22.0)) * 0.28))
		for i in range(maxi(0, n)):
			_spawn_one(base_a + randf_range(-0.55, 0.55))
		Aud.sfx("surge")
		_say(L.t("¡Marea de Pokémon!"), 2.2)
	_update_events(delta)

	preload_t -= delta
	if preload_t <= 0.0:
		preload_t = 10.0
		_preload_upcoming(t + 60.0)


func _preload_upcoming(until: float) -> void :
	for tier in cast_run:
		if float(tier["from"]) <= until:
			for d in tier["list"]:
				_preload_dex(int(d["dex"]))
	for b in boss_run:
		if float(b["at"]) <= until:
			_preload_dex(int(b["dex"]))


func _preload_dex(dex: int) -> void :
	for a in ANIMS:
		var path: String = "res://assets/pokemon/%d/%s.png" % [dex, a]
		if ResourceLoader.exists(path) and not ResourceLoader.has_cached(path):
			ResourceLoader.load_threaded_request(path)





func _update_events(delta: float) -> void :
	if event_id != "":
		event_t += delta
		if event_t >= 30.0:
			event_id = ""
			horde_defs = []
	if run_time > 0.0 and not _boss_alive():
		thief_t -= delta
		if thief_t <= 0.0 and thieves < 2:
			_spawn_thief()
			thieves += 1
			thief_t = randf_range(240.0, 360.0)
		if event_id == "":
			next_event_t -= delta
			if next_event_t <= 0.0:
				next_event_t = randf_range(240.0, 300.0)
				var ids: Array = ["horde", "gold"]
				ids.erase(last_event)
				_start_event(String(ids[randi() % ids.size()]))


func _start_event(id: String) -> void :
	last_event = id
	if id == "horde":
		var ti: int = _tier_at(run_time)
		var no_horde: = ["bomber", "healer", "shielder", "summoner"]
		var by_type: = {}
		for p in _candidates(ti):
			if no_horde.has(_behavior_of(p)):
				continue
			for ty in p["types"]:
				if not by_type.has(ty):
					by_type[ty] = []
				by_type[ty].append(p)
		var ok: Array = []
		for ty in by_type:
			if by_type[ty].size() >= 3:
				ok.append(ty)
		if ok.is_empty():
			_start_event("gold")
			return
		var type: String = String(ok[randi() % ok.size()])
		horde_defs = []
		for p in _pick_n(by_type[type], 4):
			horde_defs.append(_def_for(p, TIERS[ti], ti))
		event_id = "horde"
		event_t = 0.0
		for i in range(6):
			_spawn_one(randf() * TAU)
		_say(L.t("¡Horda de tipo %s!") % L.t(String(MD.TYPE_NAME[type])), 3.0)
	else:
		event_id = "gold"
		event_t = 0.0
		for e in enemies:
			e.make_golden()
		_say(L.t("¡Hora dorada! Doble de experiencia"), 3.0)


func _spawn_thief() -> void :
	var gold: bool = randf() < 0.25
	var dex: int = 1000 if gold else 52
	if not _dex_by.has(dex) or not _smeta.has(str(dex)):
		return
	var def: = {"dex": dex, "name": String(_dex_by[dex]["name"]), "behavior": "thief", 
		"hp": roundf(60.0 * (1.0 + run_time / 95.0) * (1.5 if gold else 1.0)), "spd": 92.0, "dmg": 0.0, "xp": 10.0, 
		"loot": "ticket10" if gold else "coins"}
	var a: float = randf() * TAU
	var pos: Vector2 = player.position + Vector2(cos(a) * randf_range(230.0, 300.0), sin(a) * randf_range(230.0, 300.0) * 0.8)
	var e: Enemy = _make_enemy(def, pos, {"hp": 1.0, "spd": 1.0, "dmg": 1.0})
	e.life = 15.0
	e.golden = true
	_ring(pos, 4.0, 40.0, Color("#ffd23f"), 0.5)
	if gold:
		_say(L.t("¡Un %s con un ticket ×10! ¡Atrápalo antes de que huya!") % e.enemy_name, 3.2)
	else:
		_say(L.t("¡Un %s cargado de monedas! ¡Atrápalo antes de que huya!") % e.enemy_name, 3.2)





func _update_enemies(delta: float) -> void :
	var kn_decay: float = pow(0.0015, delta)
	for e in enemies:
		if e.dead:
			continue
		e.touch_cd = maxf(0.0, e.touch_cd - delta)

		if e.slow_t > 0.0:
			e.slow_t -= delta
			if e.slow_t <= 0.0:
				e.slow = 0.0
		if e.burn > 0:
			e.burn_t -= delta
			e.burn_tick -= delta
			if e.burn_tick <= 0.0:
				e.burn_tick = 0.5
				_damage_enemy(e, 1.6 * float(e.burn) * (1.0 + float(player.level) * 0.06), Color("#ff9a4d"))
			if e.burn_t <= 0.0:
				e.burn = 0
		if e.dead:
			continue
		if e.poison > 0:
			e.poison_t -= delta
			e.poison_tick -= delta
			if e.poison_tick <= 0.0:
				e.poison_tick = 0.6
				_damage_enemy(e, e.max_hp * 0.012 * float(e.poison) + 1.0, Color("#d47cf0"))
			if e.poison_t <= 0.0:
				e.poison = 0
		if e.dead:
			continue
		var tint: = Color.WHITE
		if e.burn > 0:
			tint = Color(1.0, 0.75, 0.55)
		elif e.poison > 0:
			tint = Color(0.85, 0.65, 1.0)
		elif e.slow > 0.0:
			tint = Color(0.7, 0.85, 1.0)
		e.sprite.modulate = tint
		_enemy_step(e, delta, kn_decay)

	var n: int = enemies.size()
	for i in range(n):
		var a = enemies[i]
		if a.dead or a.jump != null:
			continue
		for j in range(i + 1, n):
			var b = enemies[j]
			if b.dead or b.jump != null:
				continue
			var diff: Vector2 = b.position - a.position
			var min_d: float = (a.radius + b.radius) * 0.7
			var dd: float = diff.length()
			if dd < min_d and dd > 0.001:
				var push: Vector2 = diff / dd * (min_d - dd) * 0.5
				a.position -= push
				b.position += push


func _enemy_step(e: Enemy, delta: float, kn_decay: float) -> void :
	var to: Vector2 = player.position - e.position
	var dist: float = to.length()
	var dirv: Vector2 = Vector2.ZERO
	if dist > 0.001:
		dirv = to / dist
	var spd: float = e.spd * (1.0 - e.slow) * _weather_speed(e.types)
	if not e.flying:
		spd *= _enemy_terrain(e, delta)
	if e.life > 0.0 and e.behavior == "thief":
		e.life -= delta
		if e.life <= 0.0:
			_ring(e.position, 4.0, 30.0, Color("#ffd23f"), 0.3)
			e.dead = true
			e.fade = 0.2
			return

	if e.behavior == "thief":
		e.zig += delta
		var ang: float = ( - dirv).angle() + sin(e.zig * 2.2) * 0.7
		var kk: float = 1.0 if dist < 300.0 else 0.35
		e.position += (Vector2.from_angle(ang) * spd * kk + e.knock) * delta
		e.position = _collide(e.position, e.radius * 0.5)
		e.knock *= kn_decay
		e.face_angle(ang)
		e.loop_anim("Walk", 1.4)
		return
	if e.behavior == "runner":

		var lead: float = clampf(dist / maxf(60.0, spd), 0.0, 1.4)
		var tgt: Vector2 = player.position + player_vel * lead
		var d2: Vector2 = tgt - e.position
		if d2.length() > 0.001:
			dirv = d2.normalized()

	if e.shield_t > 0.0:
		e.shield_t -= delta
		if e.shield_t <= 0.0:
			e.shield = 0.0
	if e.jump != null:
		_update_jump(e, delta)
		return
	if e.behavior == "bomber" and e.phase == "fuse":
		e.pt -= delta
		e.flash = 0.05 if int(e.pt * 10.0) % 2 == 1 else 0.0
		if e.pt <= 0.0:
			_kill_enemy(e)
		e.loop_anim("Idle", 1.0)
		return
	if e.behavior == "bomber" and dist < e.radius + player.radius + 26.0:
		e.phase = "fuse"
		e.pt = 1.0
		_hazard_zone(e.position, 62.0, 1.0, e.dmg * 1.4, e.atk_type, Color("#ff7b3d"))
		return
	if e.behavior == "shielder" or e.behavior == "jumper":
		e.skill_cd -= delta
		if e.skill_cd <= 0.0:
			if e.behavior == "shielder":
				e.skill_cd = 6.0
				_cast_shields(e)
			elif dist < 250.0:
				e.skill_cd = randf_range(5.0, 7.0)
				_start_jump(e)
				return
			else:
				e.skill_cd = 0.5
	var v: Vector2 = dirv * spd
	var abase: String = "Walk"
	if e.boss:
		var r: Array = _boss_move(e, delta, dist, dirv, spd)
		v = r[0]
		abase = String(r[1])
	elif e.behavior == "charger":
		e.pt -= delta
		if e.phase == "walk":
			if dist < 200.0 and e.pt <= 0.0:
				e.phase = "aim"
				e.pt = 0.55
				e.play("Charge", 1.6)
		elif e.phase == "aim":
			v = Vector2.ZERO
			abase = "Idle"
			if e.pt <= 0.0:
				e.phase = "dash"
				e.pt = 0.42
				e.dash_dir = dirv
				e.play("Attack", 1.4)
				_ring(e.position, e.radius, e.radius * 2.4, Color("#ff6b6b"), 0.25)
		elif e.phase == "dash":
			v = e.dash_dir * spd * 3.4
			if e.pt <= 0.0:
				e.phase = "walk"
				e.pt = 1.1
	elif KEEP_DIST.has(e.behavior):
		var rng: float = float(e.def.get("range", 200.0))
		var keep: float = rng * 0.82
		if dist < keep * 0.75:
			v = - dirv * spd * 0.8
		elif dist < keep:
			v *= 0.1
			abase = "Idle"
		e.shot_cd -= delta
		if e.shot_cd <= 0.0 and dist < rng:
			e.shot_cd = float(e.def.get("shotCd", 2.0))
			_enemy_special(e, dirv)
	e.position += (v + e.knock) * delta
	if not e.flying and e.jump == null:
		e.position = _collide(e.position, e.radius * 0.5)
	e.knock *= kn_decay
	var moving: bool = v.length() > 2.0
	var face: float = to.angle()
	if e.phase == "dash":
		face = e.dash_dir.angle()
	elif moving:
		face = v.angle()
	e.face_angle(face)
	e.loop_anim(abase if moving else "Idle", maxf(0.6, spd / 70.0) if moving else 1.0)

	var rr: float = e.radius + player.radius
	if dist <= rr and e.touch_cd <= 0.0 and e.behavior != "thief":
		e.touch_cd = 0.55
		e.strike(to.angle())
		_hurt_player(e.dmg, e.atk_type)
		e.knock = - dirv * 150.0
		if _has_item("rockyhelmet"):
			_damage_enemy(e, 15.0 + float(player.level) * 4.0, Color("#9aa6b5"), - dirv, 80.0)


func _shot_dmg(e: Enemy) -> float:
	var base_dmg: float = maxf(0.001, float(e.def.get("dmg", 1.0)))
	return float(e.def.get("shotDmg", 10.0)) * (e.dmg / base_dmg)


func _enemy_shoot(e: Enemy, ang: float, spread: float, n: int, k: float) -> void :
	for i in range(n):
		var a: float = ang
		if n > 1:
			a = ang + (float(i) / float(n - 1) - 0.5) * spread
		var b: = EBullet.new()
		b.position = e.position
		b.vel = Vector2.from_angle(a) * 190.0
		b.dmg = _shot_dmg(e) * k
		b.mtype = e.atk_type
		b.color = Color.html(String(MD.TYPE_COLOR.get(e.atk_type, "#ff7a9e")))
		fx.add_child(b)
		ebullets.append(b)
	e.play("Shoot", 1.0)
	_ring(e.position + Vector2(0.0, - LIFT), 4.0, 14.0, Color("#ff7a9e"), 0.2)


func _enemy_special(e: Enemy, dirv: Vector2) -> void :
	var col: = Color.html(String(MD.TYPE_COLOR.get(e.atk_type, "#ff7a9e")))
	var ang: float = dirv.angle()
	var b: String = e.behavior
	if b == "fan":
		var n: int = int(e.def.get("fanN", 5))
		_enemy_shoot(e, ang, 0.6 if n == 3 else 0.9, n, 0.65)
	elif b == "beamer":
		_hazard_beam(e.position, ang, 360.0, 22.0, 1.0, _shot_dmg(e) * 1.05, e.atk_type, col)
		e.play("Charge", 1.2)
	elif b == "zoner":
		var n2: int = randi_range(1, int(e.def.get("zones", 3)))
		for i in range(n2):
			var off: = Vector2.ZERO
			if i > 0:
				off = Vector2(randf_range(-70.0, 70.0), randf_range(-55.0, 55.0))
			_hazard_zone(player.position + off, 44.0, 1.2, _shot_dmg(e) * 0.95, e.atk_type, col)
		e.play("Shoot", 1.0)
	elif b == "healer":
		_heal_around(e)
	elif b == "summoner":
		_summon(e)
	else:
		_enemy_shoot(e, ang, 0.0, 1, 1.0)


func _heal_around(e: Enemy) -> void :

	var pw: float = maxf(1.0, _atk() / maxf(0.001, base_atk))
	var k: float = 0.07 * minf(2.5, pow(pw, 0.35))
	for o in enemies:
		if o.dead or o.hp >= o.max_hp:
			continue
		if o.position.distance_to(e.position) <= 150.0:
			o.hp = minf(o.max_hp, o.hp + o.max_hp * k)
			o.queue_redraw()
	e.play("Charge", 1.0)
	_ring(e.position, 8.0, 150.0, Color("#5fe08a"), 0.5)


func _cast_shields(e: Enemy) -> void :
	var near: Array = []
	for o in enemies:
		if not o.dead and o.position.distance_to(e.position) <= 160.0:
			near.append(o)
	near.sort_custom( func(a, b): return a.position.distance_squared_to(e.position) < b.position.distance_squared_to(e.position))
	for i in range(mini(6, near.size())):
		var o2 = near[i]
		o2.shield = maxf(o2.shield, o2.max_hp * 0.35)
		o2.shield_t = 8.0
	e.play("Charge", 1.0)
	_ring(e.position, 8.0, 160.0, Color("#7fc8ff"), 0.5)


func _summon(e: Enemy) -> void :
	var alive: Array = []
	for m in e.minions:
		if is_instance_valid(m) and not m.dead:
			alive.append(m)
	e.minions = alive
	if e.minions.size() >= 4 or enemies.size() > ENEMY_CAP + 15:
		return
	var dex: int = int(e.def.get("minion", e.dex))
	if not _dex_by.has(dex) or not _smeta.has(str(dex)):
		dex = e.dex
	var def: = {"dex": dex, "name": String(_dex_by[dex]["name"]), "hp": roundf(float(e.def["hp"]) * 0.35), 
		"spd": roundf(float(e.def["spd"]) * 1.1), "dmg": roundf(float(e.def["dmg"]) * 0.6), 
		"xp": maxf(1.0, roundf(float(e.def["xp"]) * 0.25)), "behavior": "chase"}
	for i in range(2):
		var a: float = randf() * TAU
		var m2: Enemy = _make_enemy(def, e.position + Vector2(cos(a) * 30.0, sin(a) * 22.0), e.sc)
		e.minions.append(m2)
	e.play("Charge", 1.0)
	_ring(e.position, 8.0, 50.0, Color("#c47bff"), 0.4)


func _start_jump(e: Enemy) -> void :
	e.jump = {"sx": e.position.x, "sy": e.position.y, "tx": player.position.x, "ty": player.position.y, "t": -0.45, "dur": 0.6}
	e.play("Charge", 1.4)
	_hazard_zone(player.position, 50.0, 1.05, e.dmg * 1.2, e.atk_type, Color.html(String(MD.TYPE_COLOR.get(e.atk_type, "#ff7a9e"))))


func _update_jump(e: Enemy, delta: float) -> void :
	var j: Dictionary = e.jump
	j["t"] = float(j["t"]) + delta
	if float(j["t"]) < 0.0:
		e.loop_anim("Idle", 1.0)
		return
	var k: float = minf(1.0, float(j["t"]) / float(j["dur"]))
	var s: = Vector2(float(j["sx"]), float(j["sy"]))
	var tg: = Vector2(float(j["tx"]), float(j["ty"]))
	e.position = s.lerp(tg, k)
	e.lift_extra = sin(k * PI) * 46.0
	e.face_angle((tg - s).angle())
	if k >= 1.0:
		e.jump = null
		e.lift_extra = 0.0
		e.play("Attack", 1.4)


func _kill_enemy(e: Enemy) -> void :
	if e.dead:
		return
	e.hp = 1.0
	_damage_enemy(e, 1.0, Color.WHITE)



func _boss_init(e: Enemy) -> void :
	var t: Array = e.types
	var melee: = ["slam", "dash" if _hash(e.dex, 3, 7) < 0.5 else "leap"]
	var pref: String = "volley"
	if _has_t(t, ["fire", "ground", "poison", "rock", "grass"]):
		pref = "rain"
	elif _has_t(t, ["electric", "psychic", "dragon", "ice", "steel"]):
		pref = "beam"
	elif _has_t(t, ["fairy", "ghost", "water", "flying"]):
		pref = "nova"
	var others: Array = ["rain", "beam", "nova", "volley"]
	others.erase(pref)
	var ranged: Array = [pref, others[int(_hash(e.dex, 5, 9) * 3.0) % 3]]
	var far: bool = e.behavior == "ranged"
	e.ai = {"melee": melee, "ranged": ranged, "far_like": 0.65 if far else 0.35, "mode": "far" if far else "close", 
		"mode_t": randf_range(6.0, 8.0), "cd": 1.6, "cast": null, "fury": false, "side": 1.0 if randf() < 0.5 else -1.0}


func _boss_enrage(e: Enemy) -> void :
	e.ai["fury"] = true
	e.spd *= 1.15
	_say(L.t("¡%s se ha enfurecido!") % e.enemy_name, 2.4)
	_ring(e.position, e.radius, e.radius * 5.0, Color("#ff4a4a"), 0.6)
	shake = 8.0


func _boss_move(e: Enemy, delta: float, dist: float, dirv: Vector2, spd: float) -> Array:
	if e.ai.is_empty():
		_boss_init(e)
	var ai: Dictionary = e.ai
	if not bool(ai["fury"]) and e.hp < e.max_hp * 0.5:
		_boss_enrage(e)
	var k: float = 1.25 if bool(ai["fury"]) else 1.0
	if ai["cast"] != null:
		return _boss_cast(e, delta)
	ai["mode_t"] = float(ai["mode_t"]) - delta
	ai["cd"] = float(ai["cd"]) - delta * k
	if float(ai["mode_t"]) <= 0.0:
		ai["mode"] = "close" if String(ai["mode"]) == "far" else "far"
		var fav: bool = (String(ai["mode"]) == "far") == (float(ai["far_like"]) > 0.5)
		ai["mode_t"] = randf_range(7.0, 9.0) if fav else randf_range(4.0, 5.0)
		ai["side"] = - float(ai["side"])
	var v: Vector2 = dirv * spd * k * 1.1
	if String(ai["mode"]) == "far":
		if dist < 170.0:
			v = - dirv * spd
		elif dist < 300.0:
			v = Vector2( - dirv.y, dirv.x) * spd * 0.55 * float(ai["side"])
	if float(ai["cd"]) <= 0.0:
		var id: String = ""
		if String(ai["mode"]) == "close":
			var ok: Array = []
			for m in ai["melee"]:
				if (m == "slam" and dist < 125.0) or (m != "slam" and dist < 320.0):
					ok.append(m)
			if not ok.is_empty() and randf() < 0.8:
				id = String(ok[randi() % ok.size()])
			elif dist < 480.0:
				id = String(ai["ranged"][randi() % 2])
		else:
			if dist < 115.0:
				id = "slam"
			elif dist < 430.0:
				id = String(ai["ranged"][randi() % 2])
		if id != "":
			_boss_start(e, id)
	return [v, "Walk"]


func _boss_start(e: Enemy, id: String) -> void :
	var ai: Dictionary = e.ai
	var f: float = 0.8 if bool(ai["fury"]) else 1.0
	var type: String = e.atk_type
	var col: = Color.html(String(MD.TYPE_COLOR.get(type, "#ff7a9e")))
	var ang: float = (player.position - e.position).angle()
	var c: = {"id": id, "t": 0.0, "wind": 0.6 * f, "after": 0.35, "ang": ang, "go": false, "fired": false, "len": 0.0, "dur": 0.0}
	ai["cast"] = c
	if id == "slam":
		c["wind"] = 0.85 * f
		_hazard_zone(e.position, 96.0 + e.radius, float(c["wind"]), e.dmg * 1.3, type, col)
		e.play("Charge", 1.2)
	elif id == "dash":
		c["wind"] = 0.75 * f
		c["len"] = 330.0
		c["dur"] = 0.32
		_hazard_beam(e.position, ang, 330.0 + e.radius, e.radius * 2.0 + 16.0, float(c["wind"]) + 0.32, e.dmg * 1.2, type, col)
		e.play("Charge", 1.3)
	elif id == "leap":
		e.jump = {"sx": e.position.x, "sy": e.position.y, "tx": player.position.x, "ty": player.position.y, "t": -0.5 * f, "dur": 0.65}
		_hazard_zone(player.position, 82.0, 0.5 * f + 0.65, e.dmg * 1.25, type, col)
		e.play("Charge", 1.4)
		ai["cast"] = null
		ai["cd"] = randf_range(1.4, 2.0) + 0.6
	elif id == "rain":
		var n: int = 6 if bool(ai["fury"]) else 4
		for i in range(n):
			var a: float = randf() * TAU if i > 0 else 0.0
			var d: float = randf_range(40.0, 120.0) if i > 0 else 0.0
			_hazard_zone(player.position + Vector2(cos(a) * d, sin(a) * d * 0.8), 50.0, 1.05 + float(i) * 0.12, _shot_dmg(e) * 1.15, type, col)
		c["wind"] = 0.5
		e.play("Shoot", 1.0)
	elif id == "beam":
		var nb: int = 5 if bool(ai["fury"]) else 3
		var sp: float = 0.42 if bool(ai["fury"]) else 0.5
		for i in range(nb):
			_hazard_beam(e.position, ang + (float(i) - float(nb - 1) / 2.0) * sp, 400.0, 26.0, 1.0, _shot_dmg(e) * 1.2, type, col)
		c["wind"] = 1.0
		c["after"] = 0.25
		e.play("Charge", 1.1)
	elif id == "volley" or id == "nova":
		c["wind"] = (0.7 if id == "nova" else 0.5) * f
		e.play("Charge", 1.4)
		_ring(e.position, e.radius, e.radius * 2.4, col, float(c["wind"]))


func _boss_cast(e: Enemy, delta: float) -> Array:
	var ai: Dictionary = e.ai
	var c: Dictionary = ai["cast"]
	c["t"] = float(c["t"]) + delta
	var id: String = String(c["id"])
	if id == "dash" and float(c["t"]) >= float(c["wind"]):
		if not bool(c["go"]):
			c["go"] = true
			e.play("Attack", 1.6)
		if float(c["t"]) >= float(c["wind"]) + float(c["dur"]):
			return _boss_end(e)
		var sp: float = float(c["len"]) / float(c["dur"])
		return [Vector2.from_angle(float(c["ang"])) * sp, "Walk"]
	if float(c["t"]) >= float(c["wind"]) and not bool(c["fired"]):
		c["fired"] = true
		var a0: float = (player.position - e.position).angle()
		var fury: bool = bool(ai["fury"])
		if id == "volley":
			_enemy_shoot(e, a0, 1.1, 9 if fury else 7, 0.8)
		elif id == "nova":
			var n: int = 18 if fury else 14
			_enemy_shoot(e, a0, TAU * float(n - 1) / float(n), n, 0.7)
		elif id == "slam":
			e.play("Attack", 1.4)
	if float(c["t"]) >= float(c["wind"]) + float(c["after"]):
		return _boss_end(e)
	return [Vector2.ZERO, "Idle"]


func _boss_end(e: Enemy) -> Array:
	var ai: Dictionary = e.ai
	ai["cast"] = null
	ai["cd"] = randf_range(1.3, 2.0)
	if bool(ai["fury"]) and randf() < 0.35:
		ai["cd"] = 0.3
	return [Vector2.ZERO, "Idle"]



func _hazard_zone(pos: Vector2, r: float, delay: float, dmg: float, type: String, col: Color) -> Hazard:
	var h: = Hazard.new()
	h.kind = "zone"
	h.position = pos
	h.r = r
	h.delay = delay
	h.dmg = dmg
	h.mtype = type
	h.color = col
	gfx.add_child(h)
	hazards.append(h)
	return h


func _hazard_beam(pos: Vector2, angle: float, length: float, width: float, delay: float, dmg: float, type: String, col: Color) -> void :
	var h: = Hazard.new()
	h.kind = "beam"
	h.position = pos
	h.angle = angle
	h.length = length
	h.width = width
	h.delay = delay
	h.dmg = dmg
	h.mtype = type
	h.color = col
	gfx.add_child(h)
	hazards.append(h)


func _hazard_inside(h: Hazard) -> bool:
	var pr: float = player.radius
	if h.kind == "zone":
		return player.position.distance_squared_to(h.position) < pow(h.r + pr * 0.6, 2.0)
	var d: Vector2 = Vector2.from_angle(h.angle)
	var rel: Vector2 = player.position - h.position
	var along: float = rel.dot(d)
	if along < - pr or along > h.length + pr:
		return false
	return absf( - rel.x * d.y + rel.y * d.x) <= h.width * 0.5 + pr * 0.6


func _update_hazards(delta: float) -> void :
	trap_slow_t = maxf(0.0, trap_slow_t - delta)
	for i in range(hazards.size() - 1, -1, -1):
		var h: Hazard = hazards[i]
		h.t += delta
		if not h.hit and h.t >= h.delay:
			h.hit = true
			if h.kind == "zone":
				_ring(h.position, 4.0, h.r, h.color, 0.35)
				if h.r > 60.0:
					shake = maxf(shake, 4.0)
			else:
				var f: = Fx.new()
				f.kind = "beam"
				f.color = h.color
				f.position = h.position
				f.ang = h.angle
				f.length = h.length
				f.width = h.width
				f.life = 0.3
				fx.add_child(f)
			if not player.dead and _hazard_inside(h):
				player.invuln = 0.0
				_hurt_player(h.dmg, h.mtype)
				if h.slows:
					trap_slow_t = 2.0
		if h.hit and h.t >= h.delay + 0.3:
			h.queue_free()
			hazards.remove_at(i)


func _update_ebullets(delta: float) -> void :
	for i in range(ebullets.size() - 1, -1, -1):
		var b: EBullet = ebullets[i]
		b.age += delta
		b.position += b.vel * delta
		var remove: bool = b.age >= 2.4
		if not remove:
			var rr: float = 7.0 + player.radius
			if b.position.distance_squared_to(player.position) < rr * rr:
				_hurt_player(b.dmg, b.mtype)
				remove = true
		if remove:
			b.queue_free()
			ebullets.remove_at(i)


func _nearest_enemy(from: Vector2, reach: float) -> Node2D:
	var best: Node2D = null
	var best_d2: float = reach * reach
	for e in enemies:
		if e.dead:
			continue
		var d2: float = from.distance_squared_to(e.position)
		if d2 <= best_d2:
			best_d2 = d2
			best = e
	return best


func _damage_enemy(e, amount: float, col: Color = Color.WHITE, dir: Vector2 = Vector2.ZERO, knock: float = 0.0, eff: String = "") -> void :
	if e.dead:
		return
	var d: float = maxf(1.0, roundf(amount))

	if e.shield > 0.0:
		var ab: float = minf(e.shield, d)
		e.shield -= ab
		if ab >= d:
			add_text(e.position + Vector2(0.0, - e.body_h - 4.0), str(roundi(d)), Color("#9fd8ff"))
			e.flash = 0.5
			return
		d -= ab
	var tc: Color = col.lerp(Color.WHITE, 0.55)
	var ts: int = 18
	if e.boss:
		ts = 24
	if eff == "super":
		tc = Color("#ffe14d")
		ts = 26
	elif eff == "weak":
		tc = Color("#a3abb8")
	add_text(e.position + Vector2(0.0, - e.body_h - 4.0), str(roundi(d)), tc, ts)
	if knock > 0.0 and dir != Vector2.ZERO and not e.boss:
		e.knock += dir.normalized() * knock
	Aud.sfx("hit")
	if e.hurt_by(d):
		kills += 1
		Aud.sfx("bossDown" if e.boss else "faint")
		_drop(e)






func _chunk_of(pos: Vector2) -> Vector2i:
	return Vector2i(floori(pos.x / CHUNK), floori(pos.y / CHUNK))


func _gen_chunk(cx: int, cy: int) -> Dictionary:
	var rng: = RandomNumberGenerator.new()
	rng.seed = absi((cx * 73856093) ^ (cy * 19349663) ^ (world_seed * 83492791)) + 1
	var org: = Vector2(float(cx) * CHUNK, float(cy) * CHUNK)
	var props: Array = []
	var pools: Array = []
	var placed: Array = []
	var far: float = (org + Vector2(CHUNK, CHUNK) * 0.5).length()

	var npool: int = 0
	var rp: float = rng.randf()
	if rp < 0.3:
		npool = 1
	elif rp < 0.42:
		npool = 2
	var deco: Array = []
	var decor: = Decor.new()
	decor.z_index = -2
	gfx.add_child(decor)
	deco.append(decor)
	for i in range(npool):
		var kind: String = "water"
		if far > 1600.0 and run_time >= 720.0 and rng.randf() < 0.4:
			kind = "lava"
		var vr: float = rng.randf()
		var variant: int = 0 if vr < 0.2 else (1 if vr < 0.5 else (2 if vr < 0.8 else 3))
		var pool: = Pool.new()
		pool.z_index = -1
		pool.setup(kind, variant)
		var pr: float = pool.r
		var pc: Vector2 = org + Vector2(rng.randf_range(90.0, CHUNK - 90.0), rng.randf_range(90.0, CHUNK - 90.0))
		var clash: = pc.length() < SAFE_R + pr
		for pl0 in placed:
			if pc.distance_to(pl0[0]) < float(pl0[1]) + pr:
				clash = true
		if clash:
			pool.queue_free()
			continue
		pool.position = pc
		gfx.add_child(pool)
		pools.append(pool)
		placed.append([pc, pr * 0.95])

	for i in range(rng.randi_range(0, 2)):
		var dp: Vector2 = org + Vector2(rng.randf_range(40.0, CHUNK - 40.0), rng.randf_range(40.0, CHUNK - 40.0))
		decor.items.append(["dirt_%d" % rng.randi_range(0, 2), dp])
	for i in range(rng.randi_range(5, 12)):
		var fp: Vector2 = org + Vector2(rng.randf_range(10.0, CHUNK - 10.0), rng.randf_range(10.0, CHUNK - 10.0))
		decor.items.append(["flower_pink" if rng.randf() < 0.6 else "flower_yellow", fp])

	var nclu: int = 1 if rng.randf() < 0.6 else 0
	for i in range(nclu):
		var cc: Vector2 = org + Vector2(rng.randf_range(60.0, CHUNK - 60.0), rng.randf_range(60.0, CHUNK - 60.0))
		for j in range(rng.randi_range(2, 4)):
			var pp: Vector2 = cc + Vector2(rng.randf_range(-90.0, 90.0), rng.randf_range(-70.0, 70.0))
			_try_prop(props, placed, "tree", pp, 15.0, rng)

	for i in range(rng.randi_range(2, 5)):
		var rr: float = rng.randf_range(16.0, 27.0)
		var pp2: Vector2 = org + Vector2(rng.randf_range(30.0, CHUNK - 30.0), rng.randf_range(30.0, CHUNK - 30.0))
		_try_prop(props, placed, "rock", pp2, rr, rng)

	if rng.randf() < 0.45:
		_try_prop(props, placed, "chest", org + Vector2(rng.randf_range(60.0, CHUNK - 60.0), rng.randf_range(60.0, CHUNK - 60.0)), 16.0, rng)
	if rng.randf() < 0.14:
		_try_prop(props, placed, "spring", org + Vector2(rng.randf_range(60.0, CHUNK - 60.0), rng.randf_range(60.0, CHUNK - 60.0)), 20.0, rng)
	if rng.randf() < 0.12:
		_try_prop(props, placed, "altar", org + Vector2(rng.randf_range(60.0, CHUNK - 60.0), rng.randf_range(60.0, CHUNK - 60.0)), 18.0, rng)
	if rng.randf() < 0.3:
		for i in range(rng.randi_range(1, 2)):
			_try_prop(props, placed, "trap", org + Vector2(rng.randf_range(60.0, CHUNK - 60.0), rng.randf_range(60.0, CHUNK - 60.0)), 16.0, rng)

	for i in range(rng.randi_range(2, 4)):
		var tc: Vector2 = org + Vector2(rng.randf_range(40.0, CHUNK - 40.0), rng.randf_range(40.0, CHUNK - 40.0))
		for j in range(rng.randi_range(2, 5)):
			_try_prop(deco, placed, "tuft", tc + Vector2(rng.randf_range(-40.0, 40.0), rng.randf_range(-26.0, 26.0)), 8.0, rng, false)
	for i in range(rng.randi_range(1, 3)):
		_try_prop(deco, placed, "bush", org + Vector2(rng.randf_range(40.0, CHUNK - 40.0), rng.randf_range(40.0, CHUNK - 40.0)), 14.0, rng, false)
	for i in range(rng.randi_range(2, 5)):
		_try_prop(deco, placed, "pebble", org + Vector2(rng.randf_range(40.0, CHUNK - 40.0), rng.randf_range(40.0, CHUNK - 40.0)), 6.0, rng, false)
	return {"props": props, "pools": pools, "deco": deco}


func _try_prop(props: Array, placed: Array, kind: String, pos: Vector2, r: float, rng: RandomNumberGenerator, reserve: bool = true) -> void :
	if pos.length() < SAFE_R + r:
		return
	for pl in placed:
		if pos.distance_to(pl[0]) < float(pl[1]) + r + 8.0:
			return
	var p: = Prop.new()
	p.kind = kind
	p.r = r
	p.solid = kind == "tree" or kind == "rock"
	p.v = rng.randf()
	p.position = pos
	if kind == "trap":
		p.sub = ["bomb", "poison", "fire", "ice", "bolt"][rng.randi() % 5]
	if kind == "altar":
		var pw: Dictionary = POWERS[rng.randi() % POWERS.size()]
		p.power = String(pw["id"])
		p.color = Color.html(String(pw["color"]))
	world.add_child(p)
	props.append(p)
	if reserve:
		placed.append([pos, r])


func _free_chunk(key: Vector2i) -> void :
	var ch: Dictionary = chunks[key]
	for p in ch["props"]:
		if is_instance_valid(p):
			p.queue_free()
	for q in ch["pools"]:
		if is_instance_valid(q):
			q.queue_free()
	for d in ch["deco"]:
		if is_instance_valid(d):
			d.queue_free()
	chunks.erase(key)


func _update_world(delta: float) -> void :
	power_t = maxf(0.0, power_t - delta)
	if power_t <= 0.0:
		power_kind = ""
	var c: Vector2i = _chunk_of(player.position)
	if c != player_chunk:
		player_chunk = c
		for dx in range(-2, 3):
			for dy in range(-2, 3):
				var key: = Vector2i(c.x + dx, c.y + dy)
				if not chunks.has(key):
					chunks[key] = _gen_chunk(key.x, key.y)
		for key in chunks.keys():
			if absi(key.x - c.x) > 3 or absi(key.y - c.y) > 3:
				_free_chunk(key)
	_update_props(delta)


func _props_near(pos: Vector2) -> Array:
	var out: Array = []
	var c: Vector2i = _chunk_of(pos)
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var ch = chunks.get(Vector2i(c.x + dx, c.y + dy))
			if ch != null:
				out.append_array(ch["props"])
	return out


func _collide(pos: Vector2, rad: float) -> Vector2:
	var c: Vector2i = _chunk_of(pos)
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var ch = chunks.get(Vector2i(c.x + dx, c.y + dy))
			if ch == null:
				continue
			for p in ch["props"]:
				if not p.solid:
					continue
				var d: Vector2 = pos - p.position
				var md: float = p.r + rad
				var dd: float = d.length_squared()
				if dd < md * md:
					if dd < 0.0001:
						d = Vector2(1.0, 0.0)
						dd = 1.0
					pos = p.position + d.normalized() * md
	return pos


func _liquid_at(pos: Vector2) -> String:
	var c: Vector2i = _chunk_of(pos)
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var ch = chunks.get(Vector2i(c.x + dx, c.y + dy))
			if ch == null:
				continue
			for q in ch["pools"]:
				if q.contains(pos):
					return String(q.kind)
	return ""


func _blocked(pos: Vector2, rad: float) -> bool:
	if _collide(pos, rad) != pos:
		return true
	return _liquid_at(pos) == "lava"


func _free_spot(pos: Vector2, rad: float) -> Vector2:
	if not _blocked(pos, rad):
		return pos
	for i in range(10):
		var q: Vector2 = pos + Vector2.from_angle(randf() * TAU) * randf_range(40.0, 170.0)
		if not _blocked(q, rad):
			return q
	return pos


func _player_terrain(delta: float) -> float:
	var liq: String = _liquid_at(player.position)
	if liq == "water":
		if _has_t(player.types, ["water", "flying"]):
			return 1.0
		return 0.72
	if liq == "lava":
		if _has_t(player.types, ["fire", "flying"]):
			return 1.0
		player_lava_t -= delta
		if player_lava_t <= 0.0:
			player_lava_t = 0.5
			player.invuln = 0.0
			_hurt_player(maxf(3.0, player.max_hp * 0.035), "")
		return 0.85
	return 1.0


func _enemy_terrain(e: Enemy, delta: float) -> float:
	var liq: String = _liquid_at(e.position)
	if liq == "water":
		if _has_t(e.types, ["water", "flying"]):
			return 1.0
		return 0.55
	if liq == "lava":
		if _has_t(e.types, ["fire"]):
			return 1.0
		e.lava_t -= delta
		if e.lava_t <= 0.0:
			e.lava_t = 0.6
			_damage_enemy(e, 6.0 + e.max_hp * 0.04, Color("#ff7b3d"))
		return 0.8
	return 1.0


func _pw(id: String) -> bool:
	return power_kind == id


func _power_text() -> String:
	if power_kind == "":
		return ""
	for p in POWERS:
		if String(p["id"]) == power_kind:
			return "%s %ds" % [String(p["name"]), ceili(power_t)]
	return ""


func _update_props(delta: float) -> void :
	var pp: Vector2 = player.position
	for p in _props_near(pp):
		if not is_instance_valid(p):
			continue
		var d: float = p.position.distance_to(pp)
		if p.kind == "chest" and not p.used and d < p.r + player.radius + 14.0:
			p.used = true
			_open_chest(p)
		elif p.kind == "spring" and not p.used and d < 52.0:
			var amt: float = minf(player.max_hp * 0.07 * delta, p.charge)
			if player.hp < player.max_hp and amt > 0.0:
				player.hp = minf(player.max_hp, player.hp + amt)
				p.charge -= amt
				p.queue_redraw()
				if p.charge <= 0.0:
					p.used = true
		elif p.kind == "altar" and not p.used and d < 50.0:
			p.used = true
			_use_altar(p)
		elif p.kind == "trap":
			p.cd = maxf(0.0, p.cd - delta)
			if p.cd <= 0.0 and d < 26.0:
				p.cd = 999.0
				_trigger_trap(p)
				var tt: Tween = p.create_tween()
				tt.tween_property(p, "modulate:a", 0.0, 0.35)
				tt.tween_callback(p.queue_free)
				_forget_prop(p)


func _trigger_trap(p: Prop) -> void :
	var base: float = 12.0 + run_time * 0.05
	var pos: Vector2 = p.position
	match p.sub:
		"bomb":
			_hazard_zone(pos, 80.0, 0.7, base * 2.0, "normal", Color("#ff8a2a"))
			get_tree().create_timer(0.7).timeout.connect( func():
				for e in enemies:
					if not e.dead and e.position.distance_to(pos) < 80.0:
						_damage_enemy(e, base * 3.0, Color("#ff8a2a")))
		"poison":
			for i in range(3):
				_hazard_zone(pos, 52.0, 0.5 + 0.7 * float(i), base * 0.5, "poison", Color("#a855f7"))
		"fire":
			_hazard_zone(pos, 58.0, 0.5, base * 1.3, "fire", Color("#ff5a28"))
		"ice":
			var hz: Hazard = _hazard_zone(pos, 60.0, 0.45, base * 0.7, "ice", Color("#7fd0ff"))
			hz.slows = true
		_:
			_hazard_zone(pos, 44.0, 0.2, base, "electric", Color("#ffe94d"))


func _forget_prop(p: Prop) -> void :
	for key in chunks:
		(chunks[key]["props"] as Array).erase(p)


func _open_chest(p: Prop) -> void :
	run_chests += 1
	Aud.sfx("chest")
	p.queue_redraw()
	_ring(p.position, 6.0, 60.0, Color("#ffd23f"), 0.45)
	var r: float = randf()
	var pos: Vector2 = p.position
	if r < 0.4:
		for i in range(10):
			_spawn_orb(pos, "coin", 5.0)
		if randf() < 0.1:
			_spawn_orb(pos, "ticket", 1.0)
		add_text(pos + Vector2(0.0, -30.0), L.t("¡Monedas!"), Color("#ffd23f"), 22)
	elif r < 0.72:
		_spawn_orb(pos, "heal", 0.0)
		var per: float = ceilf(float(_xp_for(player.level)) * 0.12 / 5.0)
		for i in range(5):
			_spawn_orb(pos, "xpBig", per)
		add_text(pos + Vector2(0.0, -30.0), L.t("¡Cofre de experiencia!"), Color("#7fe0ff"), 22)
	elif item == "" or r < 0.88:
		_spawn_orb(pos, "item", 0.0)
		add_text(pos + Vector2(0.0, -30.0), L.t("¡Un objeto!"), Color("#ff8ad8"), 22)
	else:
		_spawn_orb(pos, "magnet", 0.0)
		_spawn_orb(pos, "bomb", 0.0)
	var t: Tween = p.create_tween()
	t.tween_property(p, "modulate:a", 0.0, 0.5)
	t.tween_callback(p.queue_free)
	_forget_prop(p)


func _use_altar(p: Prop) -> void :
	for pw in POWERS:
		if String(pw["id"]) == p.power:
			power_kind = p.power
			power_t = 25.0
			_say(L.t("Altar: %s. %s (25 s)") % [L.t(String(pw["name"])), L.t(String(pw["desc"]))], 3.0)
	_ring(p.position, 6.0, 90.0, p.color, 0.6)
	p.queue_redraw()


func _cleanup_enemies() -> void :
	for i in range(enemies.size() - 1, -1, -1):
		if enemies[i].dead:
			enemies.remove_at(i)





func _bullet_hit(b, e) -> void :
	var dir: Vector2 = b.vel
	if dir == Vector2.ZERO:
		dir = e.position - player.position
	_hit_enemy(e, b.dmg, b.color, dir, b.knock, b.mtype, b.burn, b.poison, b.slow)


func _update_bullets(delta: float) -> void :
	for i in range(bullets.size() - 1, -1, -1):
		var b = bullets[i]
		b.age += delta
		if b.orb:
			b.oa += b.ospeed * delta
			b.position = player.position + Vector2(cos(b.oa) * b.orad, sin(b.oa) * b.orad * 0.7)
			for e in enemies:
				if e.dead:
					continue
				var rr: float = e.radius + b.r
				if e.position.distance_squared_to(b.position) > rr * rr:
					continue
				var key: int = e.get_instance_id()
				var last: float = float(b.hit_log.get(key, -99.0))
				if run_time - last < b.rehit:
					continue
				b.hit_log[key] = run_time
				_bullet_hit(b, e)
			if b.hit_log.size() > 300:
				b.hit_log.clear()
			continue
		var remove: bool = b.age >= b.life
		if not remove and b.boom > 0.0:
			if not b.back and b.age >= b.boom:
				b.back = true
				b.hits.clear()
			if b.back:
				var to: Vector2 = player.position - b.position
				var dd: float = to.length()
				b.vel = b.vel.lerp(to / maxf(dd, 0.001) * b.bsp, 1.0 - exp(-7.0 * delta))
				if dd < player.radius + 8.0:
					remove = true
		if not remove and b.homing > 0.0:
			var tg: Node2D = _nearest_enemy(b.position, 340.0)
			if tg != null:
				var sp: float = b.vel.length()
				var want: Vector2 = (tg.position + Vector2(0.0, - tg.body_h * 0.5) - b.position).normalized() * sp
				b.vel = b.vel.lerp(want, 1.0 - exp( - b.homing * delta))
		if not remove:
			b.ppos = b.position
			b.position += b.vel * delta
			if b.position.distance_squared_to(player.position) > 2000.0 * 2000.0:
				remove = true
		if not remove:
			for e in enemies:
				if e.dead or b.hits.has(e):
					continue
				var rr2: float = e.radius + b.r
				var cp: Vector2 = Geometry2D.get_closest_point_to_segment(e.position, b.ppos, b.position)
				if cp.distance_squared_to(e.position) > rr2 * rr2:
					continue
				b.hits.append(e)
				_bullet_hit(b, e)
				if b.pierce > 0:
					b.pierce -= 1
				else:
					remove = true
					break
		if remove:
			b.queue_free()
			bullets.remove_at(i)





func _xp_for(level: int) -> int:
	var l: float = float(level)
	return int(floor((8.0 + l * 6.0 + pow(l, 1.75) * 1.6) * 4.0))


func _gain_xp(amount: float) -> void :
	player.xp += amount * _xp_mul()
	while player.xp >= player.xp_next:
		player.xp -= player.xp_next
		player.level += 1
		player.xp_next = float(_xp_for(player.level))
		pending_levels += 1


func _spawn_orb(pos: Vector2, kind: String, value: float) -> void :
	var o: = Orb.new()
	o.kind = kind
	o.value = value
	o.position = pos
	o.vel = Vector2.from_angle(randf() * TAU) * randf_range(10.0, 46.0)
	fx.add_child(o)
	orbs.append(o)
	if orbs.size() > ORB_CAP:

		for i in range(orbs.size()):
			var old = orbs[i]
			if old.kind == "xp" or old.kind == "xpBig":
				_gain_xp(old.value)
				old.queue_free()
				orbs.remove_at(i)
				break


func _drop(e) -> void :
	if e.boss:
		run_bosses += 1
	if e.behavior == "thief":
		if String(e.def.get("loot", "coins")) == "ticket10":
			_spawn_orb(e.position, "ticket", 10.0)
		else:
			for k in range(12):
				_spawn_orb(e.position, "coin", 5.0)
		_say(L.t("¡Botín recuperado!"), 1.6)
		return
	if e.boss:
		var n: int = 14
		var per: float = ceilf(e.xp_val / float(n))
		for k in range(n):
			_spawn_orb(e.position, "xpBig", per)
		_spawn_orb(e.position + Vector2(20.0, 0.0), "heal", 0.0)
		_spawn_orb(e.position + Vector2(-20.0, 0.0), "magnet", 0.0)
		_spawn_orb(e.position + Vector2(0.0, 20.0), "item", 0.0)
		for k in range(8):
			_spawn_orb(e.position, "coin", 5.0)
		_say(L.t("¡%s derrotado!") % e.enemy_name, 2.6)
		shake = 10.0
		return
	var kind: = "xp"
	if e.xp_val >= XP_ENEMY:
		kind = "xpBig"
	_spawn_orb(e.position, kind, e.xp_val)
	var r: float = randf()
	var off: Vector2 = Vector2.from_angle(randf() * TAU) * 14.0
	if r < 0.012:
		_spawn_orb(e.position + off, "heal", 0.0)
	elif r < 0.02:
		_spawn_orb(e.position + off, "magnet", 0.0)
	elif r < 0.026:
		_spawn_orb(e.position + off, "bomb", 0.0)
	elif r < 0.041:
		_spawn_orb(e.position + off, "item", 0.0)


func _update_orbs(delta: float) -> void :
	var mag_r: float = _magnet()
	var pr: Vector2 = player.position
	for i in range(orbs.size() - 1, -1, -1):
		var o = orbs[i]
		var to: Vector2 = pr - o.position
		var d: float = to.length()
		if d < 15.0:
			var kind: String = o.kind
			var val: float = o.value
			o.queue_free()
			orbs.remove_at(i)
			_collect(kind, val)
			continue
		if o.pulled or d < mag_r:
			var pull: float = 240.0 + 1400.0 / maxf(d, 1.0)
			var tv: Vector2 = to / maxf(d, 0.001) * pull
			o.vel = o.vel.lerp(tv, 1.0 - exp(-7.0 * delta))
		else:
			o.vel *= pow(0.02, delta)
		o.position += o.vel * delta


func _collect(kind: String, value: float) -> void :
	if kind == "xp" or kind == "xpBig":
		_gain_xp(value)
		Aud.xp()
	elif kind == "heal":
		Aud.sfx("heal")
		player.hp = minf(player.max_hp, player.hp + player.max_hp * 0.3)
		add_text(player.position + Vector2(0.0, - player.body_h - 4.0), L.t("+PS"), Color("#5fe08a"))
	elif kind == "magnet":
		for o in orbs:
			if o.kind == "xp" or o.kind == "xpBig":
				o.pulled = true
		add_text(player.position + Vector2(0.0, - player.body_h - 4.0), L.t("IMAN!"), Color("#7fe0ff"))
	elif kind == "coin":
		coins += int(value)
		Aud.sfx("coin")
	elif kind == "ticket":
		tickets += int(value)
		Aud.sfx("shinyGet")
		add_text(player.position + Vector2(0.0, - player.body_h - 4.0), L.t("+%d tickets") % int(value), Color("#ffd23f"))
	elif kind == "item":
		_offer_item()
	elif kind == "bomb":
		Aud.sfx("ball")
		shake = 12.0
		for e in enemies.duplicate():
			if not e.dead and e.position.distance_to(player.position) < 520.0:
				_damage_enemy(e, 80.0, Color("#ff7b3d"))
		add_text(player.position + Vector2(0.0, - player.body_h - 4.0), L.t("BOOM!"), Color("#ff7b3d"))



func _offer() -> Array:
	var pool: Array = []
	var waiting: = {}


	if player.moves.size() < MAX_MOVES:
		var owned: = {}
		var buffs: = 0
		for m in player.moves:
			owned[String(m["id"])] = true
			if String(m["kind"]) == "buff":
				buffs += 1
		var cand: Array = []
		for id in MD.ORDER:
			var d: Dictionary = MD.MOVES[id]
			var ty: String = String(d["type"])
			if ty != "normal" and not player.types.has(ty):
				continue
			if owned.has(id) or banned.has(id):
				continue
			if buffs >= 2 and String(d["kind"]) == "buff":
				continue
			cand.append(id)
		cand.shuffle()
		for i in range(mini(6, cand.size())):
			var nid: String = String(cand[i])
			var nd: Dictionary = MD.MOVES[nid]
			pool.append({"cat": "new", "id": nid, "key": "new:" + nid, "w": 10.0, "title": String(nd["name"]), 
				"desc": String(nd["desc"]), "icon": "move:" + nid, "tag": String(MD.TYPE_NAME[String(nd["type"])]), 
				"color": Color.html(String(MD.TYPE_COLOR[String(nd["type"])]))})


	for m in player.moves:
		var ev: Dictionary = _evo_info(m)
		if ev.is_empty():
			continue
		if not bool(ev["ready"]):
			waiting[String(ev["needs"])] = m
			continue
		pool.append({"cat": "evo", "id": String(m["id"]), "key": "evo:" + String(m["id"]), "w": 40.0, 
			"title": "%s > %s" % [String(m["name"]), String(ev["name"])], "desc": String(ev["text"]), 
			"icon": "move:" + String(m["id"]), "tag": "EVOLUCIÓN", "color": Color("#ffd23f")})


	for m in player.moves:
		if int(m["lvl"]) >= _max_lvl(m):
			continue
		var ladder: Array = MD.LADDERS[String(m["kind"])]
		pool.append({"cat": "up", "id": String(m["id"]), "key": "up:" + String(m["id"]), "w": 8.0, 
			"title": String(m["name"]), "icon": "move:" + String(m["id"]), "desc": String(ladder[int(m["lvl"]) - 1]["t"]), 
			"tag": L.t("Nv.%d > %d") % [int(m["lvl"]), int(m["lvl"]) + 1], "color": _col(m)})


	var cand_s: Array = []
	for sid in STAT_IDS:
		if waiting.has(sid):
			continue
		if _lv(sid) >= int(STATS[sid]["max"]):
			continue
		cand_s.append(sid)
	cand_s.shuffle()
	var picks_s: Array = cand_s.slice(0, 5)
	for sid in waiting:
		picks_s.append(sid)
	for sid in picks_s:
		var sd: Dictionary = STATS[sid]
		var evo_for: bool = waiting.has(sid)
		var w: float = 7.0
		if evo_for:
			w = 14.0
		elif player.moves.size() < MAX_MOVES:
			w = 4.0
		var tag: = "Mejora"
		var colr: = Color("#8fa3c4")
		if evo_for:
			tag = L.t("Evoluciona ") + String(waiting[sid]["name"])
			colr = Color("#ffd23f")
		pool.append({"cat": "stat", "id": String(sid), "key": "stat:" + String(sid), "w": w, 
			"title": String(sd["title"]), "desc": String(sd["desc"]), "icon": String(STAT_ICON.get(sid, "star")), "tag": tag, "color": colr})


	var picked: Array = []
	for i in range(pool.size()):
		if String(pool[i]["cat"]) == "evo":
			picked.append(pool[i])
			pool.remove_at(i)
			break
	while picked.size() < 3 and not pool.is_empty():
		var total: = 0.0
		for c in pool:
			total += float(c["w"])
		var roll: float = randf() * total
		var idx: = pool.size() - 1
		for k in range(pool.size()):
			roll -= float(pool[k]["w"])
			if roll <= 0.0:
				idx = k
				break
		picked.append(pool[idx])
		pool.remove_at(idx)
	return picked


func _open_cards() -> void :
	var picks: Array = _offer()
	if picks.is_empty():
		pending_levels = 0
		return
	choosing = true
	Aud.sfx("levelup")
	cards.rerolls = rerolls
	cards.bans = bans
	cards.show_cards(picks, L.t("Nivel %d - elige una mejora") % player.level)


func _on_card_chosen(idx: int) -> void :
	var opts: Array = cards.items
	if idx < 0 or idx >= opts.size():
		return
	var c: Dictionary = opts[idx]
	var id: String = String(c["id"])
	var cat: String = String(c["cat"])
	if cat == "itemtake" or cat == "itemkeep":
		if cat == "itemtake":
			item = id
			add_text(player.position + Vector2(0.0, - player.body_h - 8.0), _item_name(), Color("#ff8ad8"), 22)
		cards.hide_cards()
		choosing = false
		return
	if cat == "new":
		player.moves.append(_new_move(id, 1))
		_set_active(player.moves.size() - 1)
	elif cat == "evo" or cat == "up":
		for m in player.moves:
			if String(m["id"]) == id:
				if cat == "evo":
					_evolve(m)
				else:
					_level_up_move(m)
				break
	else:
		stat_lv[id] = _lv(id) + 1
		if id == "hp":
			player.max_hp += 20.0
			player.hp = minf(player.max_hp, player.hp + 20.0)
		elif id == "heal":
			player.hp = minf(player.max_hp, player.hp + player.max_hp * 0.45)
	Aud.sfx("confirm")
	pending_levels = maxi(0, pending_levels - 1)
	cards.hide_cards()
	choosing = false





func _offer_item() -> void :
	var pool: Array = []
	for it in TD.ITEMS:
		if String(it["id"]) != item:
			pool.append(it)
	var nw: Dictionary = pool[randi() % pool.size()]
	var picks: Array = []
	picks.append({"cat": "itemtake", "id": String(nw["id"]), "key": "it:" + String(nw["id"]), "w": 1.0, 
		"title": String(nw["name"]), "desc": String(nw["desc"]), "icon": String(nw["id"]), "tag": "Objeto nuevo", "color": Color("#ff8ad8")})
	if item != "":
		var cur_desc: String = ""
		for it in TD.ITEMS:
			if String(it["id"]) == item:
				cur_desc = String(it["desc"])
		picks.append({"cat": "itemkeep", "id": item, "key": "keep", "w": 1.0, 
			"title": _item_name(), "desc": cur_desc, "icon": item, "tag": "Quedarte con el tuyo", "color": Color("#8fa3c4")})
	choosing = true
	cards.show_cards(picks, L.t("Solo puedes llevar uno: elige con cuál quedarte"), L.t("Has encontrado un objeto"), false)





func _wx_level() -> float:
	if wx_kind == "":
		return 0.0
	return clampf(minf(wx_t / 3.0, (wx_dur - wx_t) / 3.0), 0.0, 1.0)


func _weather_mult(type: String) -> float:
	if wx_kind == "":
		return 1.0
	var d: Dictionary = TD.WEATHER[wx_kind]
	var mm: Dictionary = d["mult"]
	if mm.has(type):
		return 1.0 + (float(mm[type]) - 1.0) * _wx_level()
	return 1.0


func _weather_hurts(types: Array) -> bool:
	if wx_kind == "":
		return false
	var safe: Array = TD.WEATHER[wx_kind]["safe"]
	if safe.is_empty():
		return false
	for t in types:
		if safe.has(t):
			return false
	return true


func _weather_speed(types: Array) -> float:
	if wx_kind != "" and bool(TD.WEATHER[wx_kind]["slow"]) and not types.has("ice"):
		return 1.0 - 0.1 * _wx_level()
	return 1.0


func _weather_text() -> String:
	if wx_kind == "" or _wx_level() <= 0.0:
		return ""
	return "%s  %ds" % [String(TD.WEATHER[wx_kind]["name"]), ceili(wx_dur - wx_t)]


func _weather_banner() -> String:
	if wx_kind == "" or wx_banner <= 0.0:
		return ""
	var d: Dictionary = TD.WEATHER[wx_kind]
	return "%s: %s" % [String(d["name"]), String(d["hint"])]


func _start_weather(kind: String, dur: float) -> void :
	wx_kind = kind
	wx_t = 0.0
	wx_dur = dur
	wx_banner = 3.4
	wx.setup(TD.WEATHER[kind])


func _update_weather(delta: float) -> void :
	wx_banner = maxf(0.0, wx_banner - delta)
	if wx_kind != "":
		wx_t += delta
		if wx_t >= wx_dur:
			wx_kind = ""
			wx.clear()
	elif run_time > 120.0:
		wx_check -= delta
		if wx_check <= 0.0:
			wx_check = 60.0
			if randf() < 0.18:
				var w: Dictionary = TD.BIOME_W[0]
				var total: float = 0.0
				for k in w:
					total += float(w[k])
				var roll: float = randf() * total
				var pick: String = "rain"
				for k in w:
					roll -= float(w[k])
					if roll <= 0.0:
						pick = String(k)
						break
				_start_weather(pick, roundf(randf_range(55.0, 75.0)))

	wx_chip -= delta
	if wx_chip <= 0.0:
		wx_chip = 2.0
		if wx_kind != "" and _wx_level() > 0.5:
			var wc: = Color.html(String(TD.WEATHER[wx_kind]["color"]))
			if _weather_hurts(player.types):
				var d: float = maxf(1.0, player.max_hp * 0.012)
				if player.hp > d + 1.0:
					player.hp -= d
					add_text(player.position + Vector2(0.0, - player.body_h - 4.0), "-" + str(roundi(d)), wc)
			for e in enemies:
				if e.dead or not _weather_hurts(e.types):
					continue
				if e.hurt_by(e.max_hp * 0.02 + 1.0):
					kills += 1
					_drop(e)


func add_text(pos: Vector2, text: String, color: Color, size: int = 18) -> void :
	if not dmg_on and (text.is_valid_int() or (text.begins_with("-") and text.substr(1).is_valid_int())):
		return
	var f: = Floater.new()
	f.text = L.t(text)
	f.size = size
	f.color = color
	f.position = pos
	fx.add_child(f)





class Actor extends Node2D:
	const PX: = 2.0

	var dex: = 0
	var smeta: Dictionary = {}
	var meta: Dictionary = {}
	var shiny: = false
	var scl: = 1.0
	var sprite: = Sprite2D.new()
	var mat: = ShaderMaterial.new()
	var textures: = {}
	var anim: = "Idle"
	var base: = "Idle"
	var once: = false
	var hold: = false
	var frame: = 0
	var t: = 0.0
	var anim_speed: = 1.0
	var dir: = 0
	var radius: = 12.0
	var body_h: = 40.0
	var shadow_rx: = 16.0
	var flash: = 0.0
	var fade: = -1.0
	var active: = true
	var hover: = false
	var bob: = 0.0
	var lift_extra: = 0.0
	var dirty: = true

	func setup(d: int, sm: Dictionary, shader: Shader, s: float = 1.0, shn: bool = false) -> void :
		dex = d
		smeta = sm
		meta = sm["a"]
		scl = s
		shiny = shn
		hover = bool(sm.get("hv", 0))
		mat.shader = shader
		sprite.material = mat
		sprite.centered = false
		sprite.region_enabled = true
		sprite.scale = Vector2(PX * scl, PX * scl)
		add_child(sprite)
		var idle: Dictionary = meta["Idle"] if meta.has("Idle") else meta["Walk"]
		radius = clampf(float(idle["w"]) * 0.22, 5.0, 26.0) * PX * scl
		body_h = float(idle["ay"]) * PX * scl
		var sizes: = [5.0, 8.0, 12.0]
		shadow_rx = float(sizes[clampi(int(sm.get("s", 1)), 0, 2)]) * PX * scl
		if not meta.has("Idle"):
			anim = "Walk"
			base = "Walk"
		_apply()
		queue_redraw()

	func set_shiny() -> void :
		shiny = true
		textures.clear()
		dirty = true
		_apply()

	func _am(a: String) -> Dictionary:
		if shiny and smeta.has("sa") and (smeta["sa"] as Dictionary).has(a):
			return smeta["sa"][a]
		return meta[a]

	func _tex_path(a: String, shn: bool) -> String:
		if shn:
			return "res://assets/pokemon/%d/s/%s.png" % [dex, a]
		return "res://assets/pokemon/%d/%s.png" % [dex, a]

	func _tex(a: String) -> Texture2D:
		if not textures.has(a):
			var tx: Texture2D = null
			if shiny:
				var ps: String = _tex_path(a, true)
				if ResourceLoader.exists(ps):
					tx = load(ps)
			if tx == null:
				var p: String = _tex_path(a, false)
				if ResourceLoader.exists(p):
					tx = load(p)
			textures[a] = tx
		return textures[a]

	func has_anim(a: String) -> bool:
		return meta.has(a) and _tex(a) != null

	func face_angle(a: float) -> void :
		var nd: int = posmod(int(floor((PI / 2.0 - a) / (PI / 4.0) + 0.5)), 8)
		if nd != dir:
			dir = nd
			dirty = true

	func _start(a: String) -> void :
		anim = a
		frame = 0
		t = 0.0
		dirty = true

	func loop_anim(a: String, spd: float) -> void :
		if not has_anim(a):
			a = "Idle" if has_anim("Idle") else "Walk"
		base = a
		if not once and anim != a:
			_start(a)
		if not once:
			anim_speed = spd

	func progress() -> float:
		var am: Dictionary = _am(anim)
		var total: = 0.0
		var before: = 0.0
		var i: = 0
		for dd in am["d"]:
			if i < frame:
				before += float(dd)
			total += float(dd)
			i += 1
		if total <= 0.0:
			return 1.0
		return (before + t) / total


	func play(a: String, spd: float = 1.0, hld: bool = false) -> void :
		if not has_anim(a):
			return
		if once and not hold and progress() < 0.65 and not hld:
			return
		_start(a)
		once = true
		hold = hld
		anim_speed = spd

	func play_attack(a: String, cd: float) -> void :
		if not has_anim(a):
			return
		if once and progress() < 0.65:
			return
		var am: Dictionary = _am(a)
		var total: = 0.0
		for dd in am["d"]:
			total += float(dd)
		var dur: float = total / 60.0
		_start(a)
		once = true
		hold = false
		anim_speed = maxf(1.0, dur / (maxf(0.12, cd) * 0.9))

	func tick_anim(delta: float) -> void :
		var am: Dictionary = _am(anim)
		var before_f: int = frame
		t += delta * 60.0 * anim_speed
		var guard: = 0
		while t >= float(am["d"][frame]) and guard < 16:
			guard += 1
			t -= float(am["d"][frame])
			frame += 1
			if frame >= int(am["n"]):
				if hold:
					frame = int(am["n"]) - 1
					t = 0.0
					break
				elif once:
					once = false
					anim = base
					frame = 0
					t = 0.0
					anim_speed = 1.0
					am = _am(anim)
				else:
					frame = 0
		if frame != before_f or guard > 0:
			dirty = true
		_apply()

	func _apply() -> void :
		var py: float = - (lift_extra + (sin(bob) * 3.0 if hover else 0.0) + (6.0 if hover else 0.0))
		sprite.position.y = py
		if not dirty:
			return
		dirty = false
		var am: Dictionary = _am(anim)
		var tx: Texture2D = _tex(anim)
		if tx == null:
			tx = _tex(base) if _tex(base) != null else null
			if tx == null and meta.has("Idle"):
				tx = _tex("Idle")
		sprite.texture = tx
		sprite.visible = tx != null
		sprite.offset = Vector2( - float(am["ax"]), - float(am["ay"]))
		sprite.region_rect = Rect2(frame * float(am["w"]), minf(dir, float(am.get("r", 8)) - 1.0) * float(am["h"]), float(am["w"]), float(am["h"]))

	func _process(delta: float) -> void :
		bob += delta * 6.0
		if fade >= 0.0:
			fade -= delta
			modulate.a = clampf(fade / 0.5, 0.0, 1.0)
			if once or hold:
				tick_anim(delta)
			if fade <= 0.0:
				queue_free()
			return
		if flash > 0.0:
			flash = maxf(0.0, flash - delta * 8.0)
			mat.set_shader_parameter("flash", flash)
		if active and not meta.is_empty():
			tick_anim(delta)
		elif hover or lift_extra != 0.0:
			_apply()

	func _draw() -> void :
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.42))
		draw_circle(Vector2.ZERO, shadow_rx, Color(0, 0, 0, 0.34))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


class Player extends Actor:
	var hp: = 1.0
	var max_hp: = 1.0
	var spd: = 100.0
	var atk: = 1.0
	var types: Array = []
	var invuln: = 0.0
	var dead: = false
	var aim: = PI / 2.0
	var attack_face: = 0.0
	var level: = 1
	var xp: = 0.0
	var xp_next: = 62.0
	var moves: Array = []
	var slot: = 0
	var orb_cast_t: = 0.0
	var last_patch = null
	var buffs: = {
		"atk": {"n": 0, "amount": 0.0, "t": 0.0}, 
		"spd": {"n": 0, "amount": 0.0, "t": 0.0}, 
		"def": {"n": 0, "amount": 0.0, "t": 0.0}, 
		"regen": {"n": 0, "amount": 0.0, "t": 0.0}, 
	}


class Enemy extends Actor:
	var hp: = 10.0
	var max_hp: = 10.0
	var spd: = 50.0
	var dmg: = 5.0
	var touch_cd: = 0.0
	var dead: = false
	var knock: = Vector2.ZERO
	var enemy_name: = ""
	var xp_val: = 20.0
	var types: Array = ["normal"]
	var atk_type: = "normal"
	var burn: = 0
	var burn_t: = 0.0
	var burn_tick: = 0.0
	var poison: = 0
	var poison_t: = 0.0
	var poison_tick: = 0.0
	var slow: = 0.0
	var slow_t: = 0.0
	var def: Dictionary = {}
	var boss: = false
	var behavior: = "chase"
	var flying: = false
	var sc: Dictionary = {}
	var shot_cd: = 1.0
	var skill_cd: = 2.0
	var shield: = 0.0
	var shield_t: = 0.0
	var minions: Array = []
	var jump = null
	var phase: = "walk"
	var pt: = 0.0
	var dash_dir: = Vector2.RIGHT
	var zig: = 0.0
	var life: = -1.0
	var golden: = false
	var ai: Dictionary = {}
	var lava_t: = 0.0

	func apply_burn(n: int) -> void :
		burn = mini(8, burn + n)
		burn_t = 3.0

	func apply_poison(n: int) -> void :
		poison = mini(8, poison + n)
		poison_t = 4.0

	func apply_slow(f: float, dur: float = 1.2) -> void :
		slow = maxf(slow, f)
		slow_t = maxf(slow_t, dur)

	func make_shiny() -> void :
		set_shiny()
		max_hp *= 2.0
		hp = max_hp
		xp_val *= 5.0

	func make_golden() -> void :
		if golden:
			return
		golden = true
		xp_val *= 2.0
		queue_redraw()

	func strike(angle: float) -> void :
		face_angle(angle)
		play("Attack", 1.3)


	func hurt_by(amount: float) -> bool:
		hp -= amount
		flash = 1.0
		queue_redraw()
		if hp <= 0.0:
			hp = 0.0
			dead = true
			fade = 0.9
			play("Faint", 1.0, true)
			return true
		return false

	func _draw() -> void :
		super._draw()
		if dead:
			return
		if golden:
			draw_arc(Vector2(0.0, - body_h * 0.5), radius + 4.0, 0.0, TAU, 20, Color(1.0, 0.82, 0.25, 0.7), 2.0)
		if shield > 0.0:
			draw_arc(Vector2(0.0, - body_h * 0.5), maxf(radius, body_h * 0.5) + 3.0, 0.0, TAU, 24, Color(0.5, 0.8, 1.0, 0.85), 2.5)
		if boss:
			var bw: = 90.0
			var by: float = - body_h - 14.0
			draw_rect(Rect2( - bw * 0.5, by, bw, 6.0), Color(0, 0, 0, 0.65))
			draw_rect(Rect2( - bw * 0.5, by, bw * clampf(hp / max_hp, 0.0, 1.0), 6.0), Color("#ffd23f"))
		elif hp < max_hp:
			var w: = 30.0
			var y: = - body_h - 12.0
			draw_rect(Rect2( - w * 0.5, y, w, 4.0), Color(0, 0, 0, 0.6))
			draw_rect(Rect2( - w * 0.5, y, w * clampf(hp / max_hp, 0.0, 1.0), 4.0), Color("#ff6b7a"))
		if behavior == "healer" or behavior == "shielder" or behavior == "summoner":
			var ic: Color = Color("#5fe08a") if behavior == "healer" else (Color("#7fc8ff") if behavior == "shielder" else Color("#c47bff"))
			draw_circle(Vector2(0.0, - body_h - (22.0 if boss else 20.0)), 4.0, ic)



class Hazard extends Node2D:
	var kind: = "zone"
	var r: = 40.0
	var angle: = 0.0
	var length: = 300.0
	var width: = 20.0
	var delay: = 1.0
	var dmg: = 10.0
	var mtype: = "normal"
	var color: = Color("#ff7a9e")
	var t: = 0.0
	var hit: = false
	var slows: = false

	func _process(_delta: float) -> void :
		queue_redraw()

	func _draw() -> void :
		if hit:
			return
		var k: float = clampf(t / maxf(0.01, delay), 0.0, 1.0)
		var warn: = Color(color.r, color.g, color.b, 0.16 + 0.22 * k)
		var edge: = Color(color.r, color.g, color.b, 0.75)
		if kind == "zone":
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.8))
			draw_circle(Vector2.ZERO, r, warn)
			draw_arc(Vector2.ZERO, r, 0.0, TAU, 40, edge, 2.0)
			draw_circle(Vector2.ZERO, r * k, Color(color.r, color.g, color.b, 0.3))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		else:
			var d: = Vector2.from_angle(angle)
			var n: = Vector2( - d.y, d.x) * width * 0.5
			var p1: Vector2 = d * length
			draw_colored_polygon(PackedVector2Array([n, p1 + n, p1 - n, - n]), warn)
			draw_line(n, p1 + n, edge, 2.0)
			draw_line( - n, p1 - n, edge, 2.0)
			var q: Vector2 = d * length * k
			draw_colored_polygon(PackedVector2Array([n, q + n, q - n, - n]), Color(color.r, color.g, color.b, 0.3))



class EBullet extends Node2D:
	var vel: = Vector2.ZERO
	var dmg: = 5.0
	var mtype: = "normal"
	var color: = Color("#ff7a9e")
	var age: = 0.0

	func _draw() -> void :
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.42))
		draw_circle(Vector2.ZERO, 6.0, Color(0, 0, 0, 0.3))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		draw_circle(Vector2(0.0, -18.0), 8.0, Color(color.r, color.g, color.b, 0.35))
		draw_circle(Vector2(0.0, -18.0), 5.0, color)
		draw_circle(Vector2(-1.0, -19.0), 2.0, Color(1, 1, 1, 0.85))



class WTex:
	const SC: = 3.0
	static var cache: = {}

	static func get_t(n: String) -> Texture2D:
		if not cache.has(n):
			var p: String = "res://assets/world/%s.png" % n
			cache[n] = load(p) if ResourceLoader.exists(p) else null
		return cache[n]


class Decor extends Node2D:
	var items: Array = []
	var done: = false

	func _process(_d: float) -> void :
		if not done:
			done = true
			queue_redraw()
		set_process(false)

	func _draw() -> void :
		for it in items:
			var tx: Texture2D = WTex.get_t(String(it[0]))
			if tx == null:
				continue
			var p: Vector2 = it[1]
			var sz: = Vector2(tx.get_width(), tx.get_height()) * WTex.SC
			draw_texture_rect(tx, Rect2(p - sz * 0.5, sz), false)


class Pool extends Node2D:
	var kind: = "water"
	var variant: = 0
	var tex: Texture2D = null
	var img: Image = null
	var r: = 100.0
	var tw: = 0
	var th: = 0

	func setup(k: String, v: int) -> void :
		kind = k
		variant = v
		tex = WTex.get_t("pool_%s_%d" % [k, v])
		if tex != null:
			img = tex.get_image()
			tw = tex.get_width()
			th = tex.get_height()
			r = float(maxi(tw, th)) * WTex.SC * 0.5
		else:
			r = 100.0

	func contains(p: Vector2) -> bool:
		var d: Vector2 = p - position
		if tex == null or img == null:
			var kx: float = d.x / r
			var ky: float = d.y / (r * 0.8)
			return kx * kx + ky * ky < 1.0
		var x: int = int(floor(d.x / WTex.SC + float(tw) * 0.5))
		var y: int = int(floor(d.y / WTex.SC + float(th) * 0.5))
		if x < 0 or y < 0 or x >= tw or y >= th:
			return false
		return img.get_pixel(x, y).a > 0.5

	func _draw() -> void :
		if tex != null:
			draw_texture_rect(tex, Rect2( - Vector2(tw, th) * WTex.SC * 0.5, Vector2(tw, th) * WTex.SC), false)
			return
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.8))
		draw_circle(Vector2.ZERO, r, Color("#d9531e") if kind == "lava" else Color("#2e7bbf"))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


class Prop extends Node2D:
	var kind: = "tree"
	var r: = 15.0
	var solid: = false
	var used: = false
	var v: = 0.5
	var power: = ""
	var sub: = ""
	var color: = Color.WHITE
	var charge: = 0.0
	var cd: = 0.0
	var t: = 0.0

	func _ready() -> void :
		t = v * 10.0
		if kind == "spring":
			charge = 120.0
		set_process(kind == "spring" or kind == "altar" or kind == "chest" or kind == "trap")

	func _process(delta: float) -> void :
		t += delta
		queue_redraw()

	func _spr(n: String, anchor: String = "feet", lift: float = 0.0, a: float = 1.0) -> bool:
		var tx: Texture2D = WTex.get_t(n)
		if tx == null:
			return false
		var sz: = Vector2(tx.get_width(), tx.get_height()) * WTex.SC
		var off: = Vector2( - sz.x * 0.5, - sz.y + WTex.SC)
		if anchor == "center":
			off = - sz * 0.5
		off.y -= lift
		draw_texture_rect(tx, Rect2(off, sz), false, Color(1, 1, 1, a))
		return true

	func _draw() -> void :
		var shadow: = true
		if kind == "trap" or kind == "spring" or kind == "pebble" or kind == "tuft":
			shadow = false
		if shadow:
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.42))
			draw_circle(Vector2.ZERO, r * 1.35, Color(0, 0, 0, 0.28))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		if kind == "tree":
			var n: String = "tree_a" if v < 0.38 else ("tree_b" if v < 0.76 else ("tree_dark" if v < 0.88 else "tree_autumn"))
			if _spr(n):
				return
		elif kind == "rock":
			if _spr("rock_a" if v < 0.5 else "rock_b"):
				return
		elif kind == "tuft":
			if _spr("tuft_a" if v < 0.5 else "tuft_b"):
				return
			return
		elif kind == "bush":
			if _spr("bush"):
				return
			return
		elif kind == "pebble":
			if _spr("pebble"):
				return
			return
		elif kind == "chest":
			if _spr("chest_open" if used else "chest_closed"):
				if not used:
					draw_circle(Vector2(0.0, -58.0 - 3.0 * sin(t * 3.0)), 3.0, Color(1.0, 0.9, 0.4, 0.8))
				return
		elif kind == "altar":
			var nm: String = "used" if used else power
			if _spr("altar_" + nm):
				if not used:
					var pulse: float = 0.5 + 0.5 * sin(t * 3.0)
					draw_circle(Vector2(0.0, -58.0), 14.0 + 3.0 * pulse, Color(color.r, color.g, color.b, 0.16 + 0.12 * pulse))
				return
		elif kind == "spring":
			if _spr("spring_off" if used else "spring_on", "center"):
				if not used:
					for i in range(3):
						var yy: float = - fposmod(t * 22.0 + float(i) * 14.0, 40.0)
						draw_circle(Vector2(float(i - 1) * 12.0, yy), 2.4, Color(0.8, 1.0, 0.9, 0.75))
				return
		elif kind == "trap":
			var tn: String = "trap_%s%s" % [sub, "" if cd <= 0.0 else "_off"]
			if _spr(tn, "center", 0.0 if cd > 0.0 else 3.0 * sin(t * 4.0)):
				return
		_old_draw()

	func _old_draw() -> void :
		if kind == "tree":
			var g: Color = Color("#2f7a3e").lerp(Color("#3f9a4c"), v)
			draw_rect(Rect2(-4.0, -22.0, 8.0, 22.0), Color("#6b4a2e"))
			draw_circle(Vector2(0.0, -40.0), 19.0, g)
		elif kind == "rock":
			draw_circle(Vector2(0.0, -10.0), r, Color("#7d8591"))
		elif kind == "chest":
			draw_rect(Rect2(-14.0, -22.0, 28.0, 22.0), Color("#8a5a2b"))
		elif kind == "spring":
			draw_circle(Vector2.ZERO, 25.0, Color("#5fe0a8"))
		elif kind == "altar":
			draw_rect(Rect2(-12.0, -30.0, 24.0, 30.0), Color("#8a8c94"))
		elif kind == "trap":
			draw_circle(Vector2.ZERO, 16.0, Color("#6a6a6a"))






class Bullet extends Node2D:
	const LIFT: = 18.0
	var vel: = Vector2.ZERO
	var ppos: = Vector2.ZERO
	var dmg: = 10.0
	var r: = 6.0
	var life: = 1.4
	var age: = 0.0
	var pierce: = 0
	var color: = Color.WHITE
	var hits: Array = []
	var homing: = 0.0
	var burn: = 0
	var poison: = 0
	var slow: = 0.0
	var knock: = 0.0
	var mtype: = "normal"
	var boom: = 0.0
	var bsp: = 0.0
	var back: = false
	var orb: = false
	var mid: = ""
	var oa: = 0.0
	var orad: = 60.0
	var ospeed: = 2.0
	var rehit: = 0.3
	var hit_log: = {}

	func _draw() -> void :
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.42))
		draw_circle(Vector2.ZERO, r * 0.9, Color(0, 0, 0, 0.3))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		draw_circle(Vector2(0.0, - LIFT), r * 1.4, Color(color.r, color.g, color.b, 0.35))
		draw_circle(Vector2(0.0, - LIFT), r, color)
		draw_circle(Vector2(0.0, - LIFT), r * 0.5, Color(1, 1, 1, 0.9))





class Fx extends Node2D:
	var kind: = "ring"
	var color: = Color.WHITE
	var age: = 0.0
	var life: = 0.25
	var r0: = 0.0
	var r1: = 40.0
	var ang: = 0.0
	var arc: = 1.0
	var length: = 0.0
	var width: = 10.0
	var p2: = Vector2.ZERO

	func _process(delta: float) -> void :
		age += delta
		if age >= life:
			queue_free()
		else:
			queue_redraw()

	func _draw() -> void :
		var k: float = clampf(age / life, 0.0, 1.0)
		var a: float = 1.0 - k
		var c: = Color(color.r, color.g, color.b, a * 0.85)
		var up: = Vector2(0.0, - LIFT * 0.5)
		if kind == "ring":
			draw_set_transform(up, 0.0, Vector2(1.0, 0.7))
			draw_arc(Vector2.ZERO, lerpf(r0, r1, k), 0.0, TAU, 40, c, 3.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		elif kind == "arc":
			var pts: = PackedVector2Array()
			pts.append(up)
			var n: = 14
			for i in range(n + 1):
				var t: float = float(i) / float(n)
				var aa: float = ang + (t - 0.5) * arc
				pts.append(up + Vector2.from_angle(aa) * r1 * (0.55 + 0.45 * minf(1.0, k * 3.0 + 0.3)))
			if arc >= TAU - 0.05:
				draw_circle(up, r1 * (0.55 + 0.45 * minf(1.0, k * 3.0 + 0.3)), Color(color.r, color.g, color.b, a * 0.45))
				draw_arc(up, r1, 0.0, TAU, 36, c, 4.0)
			else:
				draw_colored_polygon(pts, Color(color.r, color.g, color.b, a * 0.45))
				draw_arc(up, r1, ang - arc * 0.5, ang + arc * 0.5, 18, c, 4.0)
		elif kind == "beam":
			var d: Vector2 = Vector2.from_angle(ang)
			var start: Vector2 = Vector2(0.0, - LIFT)
			draw_line(start, start + d * length, Color(color.r, color.g, color.b, a * 0.5), width * (1.0 - k * 0.5))
			draw_line(start, start + d * length, Color(1, 1, 1, a * 0.9), width * 0.35 * (1.0 - k * 0.5))
		elif kind == "line":
			draw_line(Vector2.ZERO, p2, Color(color.r, color.g, color.b, a * 0.8), width)
			draw_line(Vector2.ZERO, p2, Color(1, 1, 1, a), width * 0.4)
		elif kind == "burst":
			draw_circle(up, r1 * (1.0 - k * 0.6), Color(color.r, color.g, color.b, a * 0.5))





class Field extends Node2D:
	var kind: = "mine"
	var color: = Color.WHITE
	var move: Dictionary = {}
	var t: = 0.0
	var life: = 3.0
	var arm: = 0.35
	var fall: = 0.5
	var r: = 40.0
	var dmg: = 0.0
	var shot_t: = 0.3
	var tick: = 0.0
	var kick: = 0.0
	var gone: = false

	func _process(_delta: float) -> void :
		queue_redraw()

	func _draw() -> void :
		var now: float = Time.get_ticks_msec() / 1000.0
		if kind == "patch":
			var a: float = clampf(minf((life - t) * 2.0, t * 6.0), 0.0, 1.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.62))
			draw_circle(Vector2.ZERO, r, Color(color.r, color.g, color.b, 0.32 * a))
			draw_arc(Vector2.ZERO, r * 0.8, 0.0, TAU, 28, Color(color.r, color.g, color.b, 0.5 * a), 1.5)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		elif kind == "mine":
			var armed: bool = t >= arm
			var blink: bool = armed and sin(now * 8.0 + position.x) > 0.3
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.62))
			draw_circle(Vector2.ZERO, r * 0.45, Color(color.r, color.g, color.b, 0.18))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			var al: float = 1.0 if blink else 0.7
			draw_circle(Vector2(0.0, -4.0), 6.0, Color(color.r, color.g, color.b, al))
			draw_circle(Vector2(0.0, -4.0), 2.5, Color(1, 1, 1, al))
		elif kind == "meteor":
			var k: float = clampf(t / fall, 0.0, 1.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.6))
			draw_circle(Vector2.ZERO, r * (0.3 + k * 0.7), Color(0, 0, 0, 0.2 + k * 0.3))
			draw_arc(Vector2.ZERO, r, 0.0, TAU, 28, Color(color.r, color.g, color.b, 0.6), 1.5)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			if t > 0.0:
				var o: = Vector2((1.0 - k) * 40.0, - (1.0 - k) * 170.0 - 6.0)
				draw_circle(o, 14.0, Color(color.r, color.g, color.b, 0.4))
				draw_circle(o, 9.0, color)
				draw_circle(o, 4.0, Color(1, 1, 1, 0.9))
		elif kind == "turret":
			var fade: float = clampf(minf((life - t) * 2.0, t * 5.0), 0.0, 1.0)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.42))
			draw_circle(Vector2.ZERO, 11.0, Color(0, 0, 0, 0.3))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			var bob: float = sin(now * 4.0 + position.x) * 2.0
			if kick > 0.0:
				bob -= 2.0
			draw_circle(Vector2(0.0, -16.0 + bob), 12.0, Color(color.r, color.g, color.b, 0.35 * fade))
			draw_circle(Vector2(0.0, -16.0 + bob), 8.0, Color(color.r, color.g, color.b, fade))
			draw_circle(Vector2(0.0, -16.0 + bob), 3.5, Color(1, 1, 1, fade))





class Slots extends Node2D:
	signal picked(idx: int)
	const SZ: = 76.0
	var info: Array = []
	var active: = 0
	var enabled: = true

	func _rects() -> Array:
		var vp: Vector2 = get_viewport_rect().size
		var n: int = info.size()
		var total: float = SZ * float(n) + 8.0 * float(maxi(0, n - 1))
		var x0: float = vp.x - total - 16.0
		var y0: float = vp.y - SZ - 14.0
		var out: Array = []
		for i in range(n):
			out.append(Rect2(x0 + float(i) * (SZ + 8.0), y0, SZ, SZ))
		return out

	func _process(_delta: float) -> void :
		queue_redraw()

	func _input(event: InputEvent) -> void :
		if not enabled:
			return
		if event is InputEventScreenTouch and event.pressed:
			var rs: Array = _rects()
			for i in range(rs.size()):
				if rs[i].has_point(event.position):
					get_viewport().set_input_as_handled()
					picked.emit(i)
					return

	func _draw() -> void :
		var font: = ThemeDB.fallback_font
		var rs: Array = _rects()
		for i in range(rs.size()):
			var r: Rect2 = rs[i]
			var it: Dictionary = info[i]
			var col: Color = it["color"]
			var is_act: bool = i == active
			var border: Color = Color("#ffd33d") if is_act else Color(col.r, col.g, col.b, 0.6)
			draw_rect(r.grow(3.0 if is_act else 1.0), border)
			draw_rect(r, Color(0.08, 0.12, 0.2, 0.9))
			IC.draw_in(self, String(it.get("icon", "star")), r.position + Vector2(SZ * 0.5, 29.0), 32.0)
			if bool(it["evo"]):
				IC.draw_in(self, "star", r.position + Vector2(SZ - 12.0, 12.0), 12.0)
			draw_string(font, r.position + Vector2(5.0, 15.0), str(i + 1), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 13, Color("#8fa8cc"))
			var nm_t: String = L.t(String(it["name"]))
			var nm_fs: int = 11
			while nm_fs > 7 and font.get_string_size(nm_t, HORIZONTAL_ALIGNMENT_LEFT, -1.0, nm_fs).x > SZ - 4.0:
				nm_fs -= 1
			draw_string(font, r.position + Vector2(2.0, 55.0), nm_t, HORIZONTAL_ALIGNMENT_CENTER, SZ - 4.0, nm_fs, Color.WHITE)
			var mx: int = int(it["max"])
			var lv: int = int(it["lvl"])
			var pw: float = (SZ - 12.0) / float(maxi(1, mx))
			for p in range(mx):
				var pc: = Color(1, 1, 1, 0.2)
				if p < lv:
					pc = Color("#ffd33d")
				draw_rect(Rect2(r.position.x + 6.0 + float(p) * pw, r.position.y + 60.0, pw - 1.5, 4.0), pc)
			draw_rect(Rect2(r.position.x, r.position.y + SZ - 6.0, SZ * float(it["frac"]), 6.0), Color(col.r, col.g, col.b, 0.8))





class Orb extends Node2D:
	var kind: = "xp"
	var value: = 20.0
	var vel: = Vector2.ZERO
	var pulled: = false

	func _draw() -> void :
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.42))
		draw_circle(Vector2.ZERO, 6.0, Color(0, 0, 0, 0.3))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		var c: = Vector2(0.0, -9.0)
		if kind == "xp":
			draw_circle(c, 8.0, Color(0.16, 0.56, 0.82, 0.35))
			draw_circle(c, 4.5, Color("#7fe0ff"))
			draw_circle(c + Vector2(-1.2, -1.4), 1.6, Color(1, 1, 1, 0.9))
		elif kind == "xpBig":
			draw_circle(c, 12.0, Color(0.75, 0.54, 0.06, 0.35))
			draw_circle(c, 7.0, Color("#ffd95e"))
			draw_circle(c + Vector2(-2.0, -2.2), 2.4, Color(1, 1, 1, 0.9))
		else:
			var icn: = "coin"
			var glow: = Color("#ffd23f")
			if kind == "ticket":
				icn = "ticket"
				glow = Color("#ff8ad8")
			elif kind == "magnet":
				icn = "magnet"
				glow = Color("#7fe0ff")
			elif kind == "bomb":
				icn = "bomb"
				glow = Color("#ff7b3d")
			elif kind == "item":
				icn = "star"
				glow = Color("#ff8ad8")
			elif kind != "coin":
				icn = "berry"
				glow = Color("#5fe08a")
			draw_circle(c + Vector2(0.0, -4.0), 15.0, Color(glow.r, glow.g, glow.b, 0.22))
			IC.draw_in(self, icn, c + Vector2(0.0, -4.0), 24.0)






class Cards extends Node2D:
	signal chosen(idx: int)
	var items: Array = []
	var sel: = 0
	var open: = false
	var age: = 0.0
	var title: = ""
	var headline: = L.t("¡Subes de nivel!")
	var _axis_free: = true
	signal reroll_pressed
	signal ban_picked(idx: int)
	var rerolls: = 0
	var bans: = 0
	var ban_mode: = false
	var extras: = true

	func _btn_rects() -> Array:
		var vp: Vector2 = get_viewport_rect().size
		return [Rect2(vp.x * 0.5 - 250.0, vp.y - 100.0, 230.0, 50.0), Rect2(vp.x * 0.5 + 20.0, vp.y - 100.0, 230.0, 50.0)]

	func _do_reroll() -> void :
		if extras and rerolls > 0 and not ban_mode:
			reroll_pressed.emit()

	func _toggle_ban() -> void :
		if extras and bans > 0:
			ban_mode = not ban_mode
			queue_redraw()

	func show_cards(list: Array, heading: String, head: String = "¡Subes de nivel!", ex: bool = true) -> void :
		items = list
		title = heading
		headline = head
		extras = ex
		ban_mode = false
		sel = 0
		open = true
		age = 0.0
		_axis_free = false
		queue_redraw()

	func hide_cards() -> void :
		open = false
		queue_redraw()

	func _rects() -> Array:
		var vp: Vector2 = get_viewport_rect().size
		var n: int = items.size()
		var gap: = 20.0
		var w: float = minf(300.0, (vp.x - 80.0 - gap * float(n - 1)) / float(maxi(n, 1)))
		var h: = 294.0
		var total: float = w * float(n) + gap * float(n - 1)
		var x0: float = (vp.x - total) * 0.5
		var y0: float = vp.y * 0.5 - 106.0
		var out: Array = []
		for i in range(n):
			out.append(Rect2(x0 + float(i) * (w + gap), y0, w, h))
		return out

	func _process(delta: float) -> void :
		if open:
			age += delta
			queue_redraw()

	func _move(step: int) -> void :
		if items.is_empty():
			return
		sel = posmod(sel + step, items.size())
		queue_redraw()

	func _pick(i: int) -> void :
		if i >= 0 and i < items.size():
			sel = i
			if ban_mode:
				if String(items[i]["cat"]) == "new":
					ban_picked.emit(i)
				return
			chosen.emit(i)

	func _input(event: InputEvent) -> void :
		if not open:
			return
		if event is InputEventJoypadMotion and event.axis == JOY_AXIS_LEFT_X:
			if absf(event.axis_value) < 0.3:
				_axis_free = true
			elif absf(event.axis_value) > 0.6 and _axis_free and age > 0.3:
				_axis_free = false
				_move(1 if event.axis_value > 0.0 else -1)
			return
		var pressed: = false
		if event is InputEventScreenTouch:
			pressed = event.pressed
		elif event is InputEventJoypadButton:
			pressed = event.pressed
		elif event is InputEventKey:
			pressed = event.pressed and not event.echo
		if not pressed:
			return

		get_viewport().set_input_as_handled()
		if age < 0.4:
			return
		if event is InputEventScreenTouch:
			var brs: Array = _btn_rects()
			if brs[0].has_point(event.position):
				_do_reroll()
				return
			if brs[1].has_point(event.position):
				_toggle_ban()
				return
			var rs: Array = _rects()
			for i in range(rs.size()):
				if rs[i].has_point(event.position):
					_pick(i)
					return
		elif event is InputEventKey:
			match event.keycode:
				KEY_1:
					_pick(0)
				KEY_2:
					_pick(1)
				KEY_3:
					_pick(2)
				KEY_LEFT, KEY_A:
					_move(-1)
				KEY_RIGHT, KEY_D:
					_move(1)
				KEY_ENTER, KEY_KP_ENTER, KEY_SPACE, KEY_E:
					_pick(sel)
				KEY_R:
					_do_reroll()
				KEY_B:
					_toggle_ban()
		elif event is InputEventJoypadButton:
			match event.button_index:
				JOY_BUTTON_DPAD_LEFT, JOY_BUTTON_LEFT_SHOULDER:
					_move(-1)
				JOY_BUTTON_DPAD_RIGHT, JOY_BUTTON_RIGHT_SHOULDER:
					_move(1)
				JOY_BUTTON_A:
					_pick(sel)
				JOY_BUTTON_Y:
					_do_reroll()
				JOY_BUTTON_X:
					_toggle_ban()

	func _draw() -> void :
		if not open:
			return
		var font: = ThemeDB.fallback_font
		var vp: Vector2 = get_viewport_rect().size
		draw_rect(Rect2(Vector2.ZERO, vp), Color(0, 0, 0, 0.6))
		draw_string(font, Vector2(0.0, vp.y * 0.5 - 150.0), L.t(headline), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 40, Color("#ffd33d"))
		draw_string(font, Vector2(0.0, vp.y * 0.5 - 118.0), L.t(title), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 20, Color.WHITE)
		var rs: Array = _rects()
		for i in range(rs.size()):
			var r: Rect2 = rs[i]
			var it: Dictionary = items[i]
			var tag_col: Color = it["color"]
			var chosen_now: bool = i == sel
			var border: Color = tag_col
			if chosen_now:
				border = Color("#ffd33d")
			draw_rect(r.grow(4.0 if chosen_now else 1.5), border)
			draw_rect(r, Color("#1b2a44"))
			draw_rect(Rect2(r.position, Vector2(r.size.x, 32.0)), Color(tag_col.r, tag_col.g, tag_col.b, 0.35))
			draw_string(font, r.position + Vector2(10.0, 22.0), L.t(String(it["tag"])), HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 40.0, 16, Color.WHITE)
			draw_string(font, r.position + Vector2(r.size.x - 24.0, 22.0), str(i + 1), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 18, Color("#8fa8cc"))
			var ic_c: Vector2 = r.position + Vector2(r.size.x * 0.5, 72.0)
			var ic_bg: = Rect2(ic_c - Vector2(34.0, 34.0), Vector2(68.0, 68.0))
			draw_rect(ic_bg, Color(tag_col.r, tag_col.g, tag_col.b, 0.22))
			draw_rect(ic_bg, Color(tag_col.r, tag_col.g, tag_col.b, 0.7), false, 2.0)
			IC.draw_in(self, String(it.get("icon", "star")), ic_c, 52.0)
			draw_multiline_string(font, r.position + Vector2(12.0, 134.0), L.t(String(it["title"])), HORIZONTAL_ALIGNMENT_CENTER, r.size.x - 24.0, 24, 2, Color.WHITE)
			draw_multiline_string(font, r.position + Vector2(16.0, 196.0), L.t(String(it["desc"])), HORIZONTAL_ALIGNMENT_CENTER, r.size.x - 32.0, 18, 5, Color("#c8d6ee"))
		if extras:
			var brs: Array = _btn_rects()
			if rerolls > 0:
				draw_rect(brs[0], Color("#1b2a44"))
				draw_rect(brs[0], Color("#7fe0ff"), false, 2.0)
				draw_string(font, brs[0].position + Vector2(0.0, 32.0), L.t("Cambiar (%d)  [R]") % rerolls, HORIZONTAL_ALIGNMENT_CENTER, brs[0].size.x, 20, Color.WHITE)
			if bans > 0:
				draw_rect(brs[1], Color("#5a1f2a") if ban_mode else Color("#1b2a44"))
				draw_rect(brs[1], Color("#ff6b7a"), false, 2.0)
				draw_string(font, brs[1].position + Vector2(0.0, 32.0), L.t("Vetar (%d)  [B]") % bans, HORIZONTAL_ALIGNMENT_CENTER, brs[1].size.x, 20, Color.WHITE)
			if ban_mode:
				draw_string(font, Vector2(0.0, vp.y * 0.5 + 214.0), L.t("Elige un movimiento nuevo para vetarlo"), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 22, Color("#ff9aa5"))
		draw_string(font, Vector2(0.0, vp.y - 24.0), L.t("Toca una carta  |  Mando: izq/der + A  |  Teclado: 1 2 3"), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 18, Color("#8fa8cc"))





class Floater extends Node2D:
	var text: = ""
	var color: = Color.WHITE
	var life: = 0.7
	var age: = 0.0
	var size: = 18

	func _process(delta: float) -> void :
		age += delta
		position.y -= 38.0 * delta
		if age >= life:
			queue_free()
		queue_redraw()

	func _draw() -> void :
		var k: float = clampf(age / life, 0.0, 1.0)
		var a: float = clampf(1.0 - k * k, 0.0, 1.0)
		var font: = ThemeDB.fallback_font
		draw_string_outline(font, Vector2(-30.0, 0.0), text, HORIZONTAL_ALIGNMENT_CENTER, 60.0, size, 4, Color(0, 0, 0, a))
		draw_string(font, Vector2(-30.0, 0.0), L.t(text), HORIZONTAL_ALIGNMENT_CENTER, 60.0, size, Color(color.r, color.g, color.b, a))






class Ground extends Node2D:
	const TILE: = 192.0
	var center: = Vector2.ZERO

	func _process(_delta: float) -> void :
		queue_redraw()

	func _draw() -> void :
		var half: Vector2 = get_viewport_rect().size * 0.5 + Vector2(TILE, TILE)
		var x0: int = int(floor((center.x - half.x) / TILE))
		var x1: int = int(ceil((center.x + half.x) / TILE))
		var y0: int = int(floor((center.y - half.y) / TILE))
		var y1: int = int(ceil((center.y + half.y) / TILE))
		var tx: Texture2D = WTex.get_t("ground_grass")
		for ix in range(x0, x1 + 1):
			for iy in range(y0, y1 + 1):
				if tx != null:
					draw_texture_rect(tx, Rect2(ix * TILE, iy * TILE, TILE, TILE), false)
				else:
					var c: = Color("#1f3d2e")
					if posmod(ix + iy, 2) == 1:
						c = Color("#244632")
					draw_rect(Rect2(ix * TILE, iy * TILE, TILE, TILE), c)






class Hud extends Node2D:
	var hp: = 1.0
	var max_hp: = 1.0
	var run_time: = 0.0
	var kills: = 0
	var dead: = false
	var show_end: = false
	var poke_name: = ""
	var level: = 1
	var xp: = 0.0
	var xp_next: = 1.0
	var buff_text: = ""
	var item_name: = ""
	var item_id: = ""
	var weather_text: = ""
	var banner: = ""
	var coins: = 0
	var tickets: = 0
	var paused: = false

	func _process(_delta: float) -> void :
		queue_redraw()

	func pause_rects() -> Array:
		var vp: Vector2 = get_viewport_rect().size
		return [Rect2(vp.x - 70.0, 70.0, 54.0, 46.0), Rect2(vp.x * 0.5 - 160.0, vp.y * 0.5, 320.0, 58.0), Rect2(vp.x * 0.5 - 160.0, vp.y * 0.5 + 76.0, 320.0, 58.0)]

	func _draw() -> void :
		var font: = ThemeDB.fallback_font
		var vp: Vector2 = get_viewport_rect().size
		var frac: float = clampf(hp / max_hp, 0.0, 1.0)
		var col: = Color("#5fe08a")
		if frac <= 0.25:
			col = Color("#ff6b7a")
		elif frac <= 0.5:
			col = Color("#ffd33d")
		draw_rect(Rect2(0.0, 0.0, vp.x, 8.0), Color(0, 0, 0, 0.55))
		draw_rect(Rect2(0.0, 0.0, vp.x * clampf(xp / xp_next, 0.0, 1.0), 8.0), Color("#7fe0ff"))
		draw_rect(Rect2(16.0, 16.0, 240.0, 18.0), Color(0, 0, 0, 0.55))
		draw_rect(Rect2(18.0, 18.0, 236.0 * frac, 14.0), col)
		draw_string(font, Vector2(16.0, 54.0), L.t("%s  PS %d/%d") % [poke_name, ceili(hp), ceili(max_hp)], HORIZONTAL_ALIGNMENT_LEFT, -1.0, 18, Color.WHITE)
		draw_string(font, Vector2(16.0, 76.0), L.t("Nv. %d") % level, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 18, Color("#7fe0ff"))
		if buff_text != "":
			draw_string(font, Vector2(16.0, 98.0), L.t(buff_text), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 16, Color("#ffd33d"))
		if item_name != "":
			IC.draw_in(self, item_id, Vector2(28.0, 124.0), 24.0)
			draw_string(font, Vector2(46.0, 130.0), L.t(item_name), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 16, Color("#ff8ad8"))
		if weather_text != "":
			draw_string(font, Vector2(0.0, 62.0), L.t(weather_text), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 18, Color("#cfe2ff"))
		if banner != "":
			draw_string(font, Vector2(0.0, 92.0), L.t(banner), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 20, Color("#ffffff"))
		var cw: float = font.get_string_size(str(coins), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 18).x
		var tw: float = font.get_string_size(str(tickets), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 18).x
		var rx: float = vp.x - 16.0
		draw_string(font, Vector2(rx - tw, 62.0), str(tickets), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 18, Color("#ff8ad8"))
		IC.draw_in(self, "ticket", Vector2(rx - tw - 16.0, 56.0), 24.0)
		rx -= tw + 40.0
		draw_string(font, Vector2(rx - cw, 62.0), str(coins), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 18, Color("#ffd23f"))
		IC.draw_in(self, "coin", Vector2(rx - cw - 16.0, 56.0), 24.0)
		var pr: Array = pause_rects()
		draw_rect(pr[0], Color(0, 0, 0, 0.45))
		draw_rect(pr[0], Color.WHITE, false, 2.0)
		draw_rect(Rect2(pr[0].position + Vector2(16.0, 12.0), Vector2(8.0, 22.0)), Color.WHITE)
		draw_rect(Rect2(pr[0].position + Vector2(30.0, 12.0), Vector2(8.0, 22.0)), Color.WHITE)
		var clock: String = "%02d:%02d" % [floori(run_time / 60.0), int(run_time) % 60]
		draw_string(font, Vector2(0.0, 36.0), L.t(clock), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 28, Color.WHITE)
		draw_string(font, Vector2(vp.x - 236.0, 36.0), L.t("Derrotados: %d") % kills, HORIZONTAL_ALIGNMENT_RIGHT, 220.0, 20, Color.WHITE)
		if dead:
			draw_rect(Rect2(Vector2.ZERO, vp), Color(0, 0, 0, 0.5))
			draw_string(font, Vector2(0.0, vp.y * 0.45), L.t("Has caído..."), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 48, Color.WHITE)
			draw_string(font, Vector2(0.0, vp.y * 0.45 + 40.0), L.t("Aguantaste %s y derrotaste %d") % [clock, kills], HORIZONTAL_ALIGNMENT_CENTER, vp.x, 22, Color.WHITE)
			pass
		if paused:
			draw_rect(Rect2(Vector2.ZERO, vp), Color(0, 0, 0, 0.6))
			draw_string(font, Vector2(0.0, vp.y * 0.5 - 40.0), L.t("Pausa"), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 56, Color.WHITE)
			for i in range(1, 3):
				var rr: Rect2 = pr[i]
				draw_rect(rr, Color("#1c3a8c"))
				draw_rect(rr, Color("#ffd33d") if i == 1 else Color("#ff6b7a"), false, 3.0)
				draw_string(font, rr.position + Vector2(0.0, 38.0), L.t("Continuar  [Enter / A]") if i == 1 else L.t("Abandonar  [X / B]"), HORIZONTAL_ALIGNMENT_CENTER, rr.size.x, 24, Color.WHITE)
		if dead:
			if show_end:
				draw_string(font, Vector2(0.0, vp.y * 0.45 + 84.0), L.t("Pulsa una tecla, un botón o toca la pantalla para volver al menú"), HORIZONTAL_ALIGNMENT_CENTER, vp.x, 20, Color("#ffd33d"))





class WeatherFx extends Node2D:
	var kind: = ""
	var level: = 0.0
	var def: Dictionary = {}
	var parts: Array = []

	func setup(d: Dictionary) -> void :
		def = d
		parts.clear()

	func clear() -> void :
		def = {}
		parts.clear()
		queue_redraw()

	func _new_part(vp: Vector2, anywhere: bool) -> Dictionary:
		var y: float = randf() * vp.y if anywhere else -10.0
		if kind == "rain":
			return {"x": randf() * (vp.x + 200.0), "y": y, "vx": -120.0, "vy": 720.0, "t": 0.0, "life": 9.0}
		if kind == "snow":
			return {"x": randf() * vp.x, "y": y, "vx": randf_range(-20.0, 20.0), "vy": randf_range(40.0, 80.0), "t": 0.0, "life": 20.0}
		if kind == "sand":
			return {"x": randf() * vp.x if anywhere else vp.x + 20.0, "y": randf() * vp.y, "vx": randf_range(-520.0, -380.0), "vy": randf_range(20.0, 60.0), "t": 0.0, "life": 9.0}
		return {"x": randf() * vp.x, "y": randf() * vp.y if anywhere else vp.y + 5.0, "vx": randf_range(-8.0, 8.0), "vy": - randf_range(15.0, 30.0), "t": 0.0, "life": 12.0}

	func _process(delta: float) -> void :
		if kind == "" or level <= 0.0 or def.is_empty():
			if not parts.is_empty():
				parts.clear()
				queue_redraw()
			return
		var vp: Vector2 = get_viewport_rect().size
		var want: int = int(float(def["parts"]) * level * (vp.x / 1280.0))
		while parts.size() < want:
			parts.append(_new_part(vp, true))
		if parts.size() > want + 4:
			parts.resize(want)
		for i in range(parts.size()):
			var p: Dictionary = parts[i]
			p["x"] = float(p["x"]) + float(p["vx"]) * delta
			p["y"] = float(p["y"]) + float(p["vy"]) * delta
			p["t"] = float(p["t"]) + delta
			if float(p["y"]) > vp.y + 20.0 or float(p["x"]) < -40.0 or float(p["x"]) > vp.x + 40.0 or float(p["y"]) < -40.0 or float(p["t"]) > float(p["life"]):
				parts[i] = _new_part(vp, false)
		queue_redraw()

	func _draw() -> void :
		if kind == "" or level <= 0.0 or def.is_empty():
			return
		var vp: Vector2 = get_viewport_rect().size
		var t: Array = def["tint"]
		draw_rect(Rect2(Vector2.ZERO, vp), Color(float(t[0]), float(t[1]), float(t[2]), float(t[3]) * level))
		var s: float = maxf(2.0, roundf(vp.x / 640.0))
		for p in parts:
			var pos: = Vector2(float(p["x"]), float(p["y"]))
			if kind == "rain":
				draw_line(pos, pos + Vector2( - s * 1.2, - s * 5.0), Color(0.81, 0.89, 1.0, 0.5 * level), s * 0.5)
			elif kind == "snow":
				draw_rect(Rect2(pos, Vector2(s, s)), Color(1, 1, 1, 0.7 * level))
			elif kind == "sand":
				draw_rect(Rect2(pos, Vector2(s * 3.0, s * 0.5)), Color(0.91, 0.81, 0.56, 0.4 * level))
			else:
				draw_rect(Rect2(pos, Vector2(s, s)), Color(1.0, 0.95, 0.69, 0.45 * level))





class Stick extends Node2D:
	var radius: = 90.0
	var axis: = Vector2.ZERO
	var _id: = -1
	var _origin: = Vector2.ZERO
	var _pos: = Vector2.ZERO

	func _input(event: InputEvent) -> void :
		if event is InputEventScreenTouch:
			if event.pressed and _id == -1:
				_id = event.index
				_origin = event.position
				_pos = event.position
			elif not event.pressed and event.index == _id:
				_id = -1
				axis = Vector2.ZERO
			queue_redraw()
		elif event is InputEventScreenDrag and event.index == _id:
			var v: Vector2 = event.position - _origin
			if v.length() > radius:
				v = v.normalized() * radius
			_pos = _origin + v
			axis = v / radius
			queue_redraw()

	func _draw() -> void :
		if _id == -1:
			return
		draw_arc(_origin, radius, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 3.0)
		draw_circle(_pos, 28.0, Color(1, 1, 1, 0.45))
